function init()
    staticSets = FindShapes('setStatic', true)
    for i=1,#staticSets do
        SetBodyActive(GetShapeBody(staticSets[i]), false)
    end

    cableShapes = FindShapes('powerCable', true)
    for i=1,#cableShapes do
        SetBodyActive(GetShapeBody(cableShapes[i]), true)
    end

    coolers = FindJoints('cooler', true)
    for i=1,#coolers do
        SetJointMotor(coolers[i], 12, 50)
    end

    hddDrives = FindJoints('hddDrive', true)
    for i=1,#hddDrives do
        SetJointMotor(hddDrives[i], 30, 50)
    end

    gpuCoolers = FindJoints('gpuCooler', true)
    for i=1,#gpuCoolers do
        SetJointMotor(gpuCoolers[i], 15, 50)
    end

    fanNoise = LoadLoop('sfx/fan.ogg')
    hddNoise = LoadLoop('sfx/hdd.ogg')
end

local powerOn = true
local brokeWaterPipe = false
local particleTimer = 0
local particleTimerInit = 3
local startSpawn = 2
local totalJijas = 25
local lastParticle = 0

function runParticlesOnce()
    local particles = FindLocations('waterPipeParticles', true)
    for i=1,#particles do
        ParticleType("smoke")
        ParticleTile(4)
        ParticleRadius(0.07, 0.12)
        ParticleAlpha(1.0, 0.0)
        ParticleGravity(-10)
        ParticleCollide(1, 1, "constant", 0.05)
        ParticleColor(0, 0.7, 0, 0.3, 1, 0.3)
        ParticleCollide(c0,Collide,c1,collide,interpolation,fadein,fadeout)
        SpawnParticle(GetLocationTransform(particles[i]).pos, Vec(0, -0.5, 0), 10.0)
    end
end

function turnOff()
    powerOn = false

    for i=1,#coolers do
        SetJointMotor(coolers[i], 0, 25)
    end

    for i=1,#hddDrives do
        SetJointMotor(hddDrives[i], 0, 25)
    end

    for i=1,#gpuCoolers do
        SetJointMotor(gpuCoolers[i], 0, 40)
    end
end


function tick(dt)
    if (powerOn) then
        local fanSfxLocs = FindLocations('fanSfx', true)
        for i=1,#fanSfxLocs do
            PlayLoop(fanNoise, GetLocationTransform(fanSfxLocs[i]).pos, 1)
        end

        local hddSfxLocs = FindLocations('hddSfx', true)
        for i=1,#hddSfxLocs do
            PlayLoop(hddNoise, GetLocationTransform(hddSfxLocs[i]).pos, 1)
        end

        local powerCablePos = FindLocation('powerPlug', true)
        local powerCableConnectorPos = GetShapeBody(FindShape('powerPlugConnector', true))
        local dist = VecLength(VecSub(GetLocationTransform(powerCablePos).pos, GetBodyTransform(powerCableConnectorPos).pos))
        if (dist > 1) then
            turnOff()
        end
        if (IsShapeBroken(FindShape('powersupply', true))) then
            turnOff()
        end
        for i=1,#cableShapes do
            if (IsShapeBroken(cableShapes[i])) then
                turnOff()
            end
        end
    end

    if (IsShapeBroken(FindShape('waterPipe', true)) and not brokeWaterPipe) then
        particleTimer = particleTimerInit
        brokeWaterPipe = true
    end

    if (particleTimer > 0) then
        particleTimer = particleTimer - dt
        runParticlesOnce()
        local currParticle = math.ceil((particleTimerInit - particleTimer - startSpawn) / (particleTimerInit - startSpawn) * totalJijas)
        if (lastParticle ~= currParticle and currParticle > 0) then
            local jija = FindShapes('jija', true)
            local jijaSetPoint = FindLocation('jijaSetPoint', true)
            SetBodyTransform(GetShapeBody(jija[currParticle]), GetLocationTransform(jijaSetPoint))
        end
    end
end