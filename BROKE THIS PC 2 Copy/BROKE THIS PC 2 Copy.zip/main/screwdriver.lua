local movedElement, isMoving = false

function init()
	RegisterTool("screwdriver", "Granddad's screwdriver", "MOD/main/ot.vox")
	SetBool("game.tool.screwdriver.enabled", true)
end

function DebugBox(pointA, pointB)
	DebugLine(pointA, {pointA[1], pointB[2], pointA[3]})
	DebugLine(pointA, {pointB[1], pointA[2], pointA[3]})
	DebugLine(pointA, {pointA[1], pointA[2], pointB[3]})
	DebugLine(pointB, {pointB[1], pointB[2], pointA[3]})
	DebugLine(pointB, {pointB[1], pointA[2], pointB[3]})
	DebugLine(pointB, {pointA[1], pointB[2], pointB[3]})
	DebugLine({pointA[1], pointB[2], pointA[3]}, {pointB[1], pointB[2], pointA[3]})
	DebugLine({pointA[1], pointB[2], pointA[3]}, {pointA[1], pointB[2], pointB[3]})
	DebugLine({pointB[1], pointA[2], pointB[3]}, {pointA[1], pointA[2], pointB[3]})
	DebugLine({pointB[1], pointA[2], pointB[3]}, {pointB[1], pointA[2], pointA[3]})
	DebugLine({pointB[1], pointA[2], pointA[3]}, {pointB[1], pointB[2], pointA[3]})
	DebugLine({pointA[1], pointA[2], pointB[3]}, {pointA[1], pointB[2], pointB[3]})
end

function tick()
	if GetString("game.player.tool") == "screwdriver" then

		local offset = Transform(Vec(0.7, -0.5, -1.5), QuatEuler(0,90,25))
		SetToolTransform(offset)

		--SetString("game.tool.screwdriver.ammo.display", "Select an object to transport")
		local t = GetCameraTransform()
		local dir = TransformToParentVec(t, {0, 0, -1})
		local hit, dist, normal, shape = QueryRaycast(t.pos, dir, 10)
		if hit and not isMoving then
			local hitPoint = VecAdd(t.pos, VecScale(dir, dist))
			local min, max = GetShapeBounds(shape)
			--DebugBox(min, max)
			DrawShapeOutline(shape, 1)
			if InputPressed("usetool") then
				movedElement = shape
				isMoving = true
			end
		elseif hit and isMoving then 
			if InputPressed("usetool") then
				local bodyHandle = GetShapeBody(movedElement)
				local movedBodyTrans = GetBodyTransform(bodyHandle)
				local x, y, z, s = GetShapeSize(movedElement)
				movedBodyTrans.pos = VecAdd(t.pos, VecScale(dir, dist))
				movedBodyTrans.pos = VecAdd(movedBodyTrans.pos, Vec(0, y * s / 2))
				SetBodyTransform(bodyHandle, movedBodyTrans)
				isMoving = false
			end
		end

		if isMoving then
			--SetString("game.tool.screwdriver.ammo.display", "Select new position for object")
			DrawShapeOutline(movedElement, 0, 0, 1, 1)
			if InputPressed("grab") then
				isMoving = false
			end
		end
	end
end