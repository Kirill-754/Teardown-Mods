function draw()
	UiTranslate(UiCenter(), 250)
	UiAlign("center middle")

	--Title
	UiFont("bold.ttf", 48)
	UiText("Speedometer options")

	--Draw speedometer
	UiTranslate(0, 200)
	UiPush()
		if GetBool("savegame.mod.mph") then
			UiImage("mph.png")
		else
			UiImage("kmh.png")
		end
		UiRotate(math.deg(math.sin(GetTime())-1.0))
		UiImage("needle.png")
	UiPop()
	
	--Draw buttons
	UiTranslate(0, 200)
	UiFont("regular.ttf", 26)
	UiButtonImageBox("ui/common/box-outline-6.png", 6, 6)
	UiPush()
		UiTranslate(-110, 0)
		if not GetBool("savegame.mod.mph") then
			UiPush()
				UiColor(0.5, 1, 0.5, 0.2)
				UiImageBox("ui/common/box-solid-6.png", 200, 40, 6, 6)
			UiPop()
		end
		if UiTextButton("Metric KM/H", 200, 40) then
			SetBool("savegame.mod.mph", false)
		end
		UiTranslate(220, 0)
		if GetBool("savegame.mod.mph") then
			UiPush()
				UiColor(0.5, 1, 0.5, 0.2)
				UiImageBox("ui/common/box-solid-6.png", 200, 40, 6, 6)
			UiPop()
		end
		if UiTextButton("Imperial MPH", 200, 40) then
			SetBool("savegame.mod.mph", true)
		end
	UiPop()
	
	UiTranslate(0, 100)
	if UiTextButton("Close", 200, 40) then
		Menu()
	end
end

