Heist Example

The scene in this example contains two groups, Map and Heist components, the Heist Component group contains everything you need to set up your own heist mission and the Map group contains the ground, water and buildings.

--- mod custom script ---

--main.lua
This script handles the score tracking and saving as well as the end screens, this is the only custom script in the mod, all other scripts are the same as the ones used in the main game. All other scripts can be found in the installation directory under Teardown/data/scripts

--- teardown game built in scripts ----

--heist.lua
This script handles the targets and the alarms. It also takes parameters to set which music to play, if fire alarms should be active, a time limit that starts the countdown as soon as the level starts and a required parameter. 
If you set up a heist with only optional targets and want the player to complete the level when a set amount of those optional targets have been collected you should use the required parameter. If you place 5 optional targets in a level and set the required parameter to 3, the player can complete the level by taking any 3 optional targets.
music = lee.ogg
firealarm = false
timelimit = 40
required = 0

--alarmbox.lua
The alarmbox script triggers the alarm if the rope connected to the target is broken, if the target is picked up or if the alarmbox is tampered with.

--alarmlight.lua
The alarm light script makes the light flash once the alarm is triggered. The script has 4 different behaviors that can be specified with the type parameter. Examples of all four types can be found in this example.
1) Slow blink
2) Three short flashes
3) Fast blink
4) Rotating light (no sound)

--escape.lua
The escape script handles the escape vehicle driving away once all targets are cleared, adding the highlight arrow above the escape vehicle and setting the position of the escape camera.
The escape vehicle should be a body tagged with "escapevehicle unbreakable"
The arrow will show up if there is a location with the tag "arrow"
The escape camera that follows the player driving away is located at the location tagged "escapecamera"

--alarmchopper.lua
The alarm chopper script handles the helicopter logic, it contains the model for the helicopter in the "chopper [instance]" as well as the start and end positions for the helicopter.

--- special objects ----

--targets
To set up a target create a body and give it the "target" tag, to make a target optional add "optional" as a tag. To prevent the player from breaking the target also add the tag "unbreakable".
It's important that the target is a body and not a vox and that the vox model inside the body has prop set to false.
tags = target unbreakable
tags = target optional unbreakable

--spawnpoint
The spawnpoint is what decides where the player should start when entering the level.