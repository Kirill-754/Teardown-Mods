--[[
#include "umf.lua"
#include "tool_skins.lua"
#include "version.lua"
]] --

function DrawRequirementNotify()
    if  TDMP_LocalSteamID then return end
   
		
		local mods = ListKeys("mods.available")
		local activeMods = {}
		local more = 0
		for i=1, #mods do
			local active = GetBool("mods.available."..mods[i]..".active") and (string.sub(mods[i], 1, 5) == "TDMP_" or string.sub(GetString("mods.available."..mods[i]..".name"), 1, 6) == "[TDMP]" )
			if active then
			    if #activeMods > 8 and showLargeUI then
					more = more +1
				elseif #activeMods > 10 then
					more = more + 1
				else
					local name = GetString("mods.available."..mods[i]..".name")
					if string.len(name) > 128 then
						activeMods[#activeMods+1] = string.sub(name, 1, 128) .. "..."
					else
						activeMods[#activeMods+1] = name
					end
				end
			end
		end
		if more > 0 then
			activeMods[#activeMods+1] = "...and "..more.." more"
		end

        if #activeMods == 0 then return end
        UiColor(0,0,0, 1)
        UiRect(UiWidth(), UiHeight())
        UiFont("regular.ttf", 24)
            UiAlign("center middle")
            UiTranslate(UiCenter(), UiMiddle())
            UiColor(1, 0, 0)
            local scale = 1
            UiPush()
                showLargeUI = GetBool("game.largeui")
                if showLargeUI then
                    UiScale(scale*1.3)
                else 
                    UiScale(scale)
                end
          --      UiTranslate(0, -24)
        --	UiText("PLEASE INSTALL TEARDOWN MULTIPLAYER FOR THESE MODS TO WORK")
            UiPop()
        UiColor(0.96, 0.96, 0.96)
		if #activeMods > 0 then
			UiPush()
				UiFont("regular.ttf", 22)
				local width = 200
				local height = 48+#activeMods*UiFontHeight()
				--UiTranslate(0, 250)
				for i=1, #activeMods do
					local w,h = UiGetTextSize(activeMods[i])
					w = w + 60
					if w > width then
						width = w
					end
				end
				showLargeUI = GetBool("game.largeui")
				if showLargeUI then
					UiScale(1.3)
				end
				UiImageBox("ui/common/box-outline-6.png", width, height, 6, 6)
				UiWindow(width, height)
           
				UiAlign("left")
				UiPush()
					UiTranslate(width*0.5, -15)
                    UiPush()
                    UiColor(1,0,0)
                    UiFont("regular.ttf", 24)
                    local w, h = UiGetTextSize("INSTALL TEARDOWN MULTIPLAYER FOR THESE MODS TO WORK")
                    local offset = -(w/2)
                    UiTranslate(offset, -h)
                    UiText("INSTALL TEARDOWN MULTIPLAYER FOR THESE MODS TO WORK")
                UiPop()
					UiColor(0,0,0)
					--UiRect(120, 30)
					UiColor(0.96, 0.96, 0.96)
                    
                    local size, sizey = UiGetTextSize("MODS THAT REQUIRE TDMP")
                    local offset = -(size/2)
					UiTranslate(offset, 0) ---sizey/10
					UiText("MODS THAT REQUIRE TDMP")
				UiPop()
				UiTranslate(30, 44)
				UiColor(1,1,0.7)
				for i=1, #activeMods do
					UiText(activeMods[i], true)
				end
			UiPop()
		end
end


function draw()
	DrawRequirementNotify()
end

if not TDMP_LocalSteamID then return end
#include "tdmp/networking.lua"
#include "tdmp/json.lua"
#include "tdmp/player.lua"
local config = OptionsKeys {
	legacy = { "boolean", false },
	rotspeed = { "number", 1 },
	bottom = { "boolean", true },
	key = {
		invert = { "boolean", false },
		rotate = { "string", "interact" },
		throw = { "string", "r" },
		unfreeze = { "string", "r" },
		rotlock = { "string", "mmb" },
	},
	experimental = {
		constrain = { "boolean", false },
		rotlock = { "boolean", false },
		toolgroup = { "integer", 6 },
	},
	skin = { "string", DEFAULT_SKIN }
}

local state = util.structured_table( "game.tool.physgun", {
	bottom = "boolean",
	grabbed = "body",
	grabbing = "boolean",
	relative = "vector",
	dist = "number",
	action = "string",
	rotating = "boolean",
	effect = {
		freeze_time = "number",
		freeze_body = "body",
		unfreeze_time = "number",
		unfreeze_body = "body",
	}
} )
state.bottom = config.bottom

local DEBUG = false

if DEBUG then
	PRINTTOSCREEN = true
end

local TOOL = {}

TOOL.noregister = ActivateSkin( "physgun", config.skin, config.experimental.toolgroup or 6 )

TOOL.ammo = 10000

--TODO: make invert code readable somehow
local _lmb, _rmb = "usetool", "grab"
if config.key.invert then
	_lmb, _rmb = "grab", "usetool"
end

local playerStates = {}
local playerPhysgunBeamEnabled = {}
local body_meta body_meta = global_metatable( "body", "entity" )
function MetaBody( handle ) 
	if handle > 0 then 
		return setmetatable( { handle = handle, type = "body" }, body_meta ) 
	end 
end 
local VEC_ZERO = Vec(0,0,0)
TDMP_RegisterEvent("TDMP_PHYSGUN_SETGRAB", function(rawdata,sender)
	data = json.decode(rawdata)
	sender = (sender and sender ~= "" and sender) or data[3]
	--if TDMP_IsServer() and (sender == TDMP_LocalSteamID) then return end
	local body = 0
	if data[1] > 0 then
		 body = TDMP_GetBodyByNetworkId(data[1])
	end

	
	if ((body > 0) and (TOOL.world[body] or HasTag(body, "ground")  ) ) then
		return
	end
	--DebugPrint(body)
	
	if body > 0 then
			local metabody = MetaBody(body)
			metabody:SetDynamic( true )
			metabody:SetVelocity( VEC_ZERO )
			if body then
				if not metabody:IsDynamic() then
					state.effect.unfreeze_time = GetTime()
					state.effect.unfreeze_body = body
					state.action = "unfreeze"
				end
				metabody:SetDynamic( true )
				metabody:SetVelocity( Vector( 0, 0, 0 ) )
			end
	end


	local freeze = data[2]
	--DebugPrint(freeze)

	if playerStates[sender] then 
		if playerStates[sender][2] and freeze then
			--DebugPrint(playerStates[sender][2])
			local metabody2 = MetaBody(playerStates[sender][2])
			if metabody2 then
				metabody2:SetDynamic( false )
				metabody2:SetVelocity( VEC_ZERO )
				metabody2:SetAngularVelocity( VEC_ZERO )
			end
		end
	end

	playerStates[sender] = {data[1], body}
	
	if not TDMP_IsServer() then return end
	
	data[3] = sender
	
	TDMP_ServerStartEvent("TDMP_PHYSGUN_SETGRAB", {
		Receiver = TDMP.Enums.Receiver.ClientsOnly,
		Reliable = true,

		DontPack = false,
		Data = data
	})

end)

TDMP_RegisterEvent("TDMP_PHYSGUN_THROW", function(rawdata, sender)
	if not TDMP_IsServer() then return end
	if not playerStates[sender] then return end
	if not playerStates[sender][2] then return end
	if playerStates[sender][2] <= 0 then return end
	local metabody2 = MetaBody(playerStates[sender][2])
	local camtr = Player(sender):GetCamera()
	local fwd = TransformToParentVec(camtr,Vec(0,0,-1))
	local fwdScale = VecScale(fwd,-100)
	metabody2:SetVelocity(fwdScale) -- camtr.rot:Forward() * -100 )
end)

TDMP_RegisterEvent("TDMP_PHYSGUN_UNFREEZE", function(rawdata, sender)
	data = json.decode(rawdata)
	sender = (sender and sender ~= "" and sender) or data[2]
	local body = -2
	if data[1] > 0 then
		 body = TDMP_GetBodyByNetworkId(data[1])
	end
	if body > 0 then
		local metabody2 = MetaBody(playerStates[sender][2])
		if not body:IsDynamic() then
			state.effect.unfreeze_time = GetTime()
			state.effect.unfreeze_body = body
			state.action = "unfreeze"
		end
		body:SetDynamic( true )
		body:SetVelocity( Vector( 0, 0, 0 ) )
	end

	if not TDMP_IsServer() then return end
	
	data[2] = sender
	
	TDMP_ServerStartEvent("TDMP_PHYSGUN_SETGRAB", {
		Receiver = TDMP.Enums.Receiver.ClientsOnly,
		Reliable = true,

		DontPack = false,
		Data = data
	})
end)

TDMP_RegisterEvent("TDMP_PHYSGUN_SETPOS", function(rawdata, sender)
	if not TDMP_IsServer() then return end
	--if sender == TDMP_LocalSteamID then return end
	if not playerStates[sender] then return end
	if not playerStates[sender][2] then return end
	if playerStates[sender][2] <= 0 then return end
	data = json.decode(rawdata)
	-- Maybe not set position on server idk
	--SetBodyTransform(playerStates[sender][2], Transform(data[1], data[2]))
	local metabody2 = MetaBody(playerStates[sender][2])
	metabody2:SetVelocity(data[1])
	metabody2:SetAngularVelocity(data[2])
end)

TDMP_RegisterEvent("TDMP_PHYSGUN_SETSTATE", function(rawdata, sender)
	data = json.decode(rawdata)
	sender = (sender and sender ~= "" and sender) or data[2]
	if not playerStates[sender] then return end
	if not playerStates[sender][2] then return end
	if playerStates[sender][2] <= 0 then return end
	local bodymeta = MetaBody(playerStates[sender][2])
	if data[1] then
		bodymeta:SetVelocity( VEC_ZERO )
		bodymeta:SetAngularVelocity( VEC_ZERO )
		bodymeta:SetDynamic( false )
	else
		bodymeta:SetDynamic( true )
		bodymeta:SetVelocity( VEC_ZERO )
	end
	if not TDMP_IsServer() then return end
	data[2] = sender
	TDMP_ServerStartEvent("TDMP_PHYSGUN_SETSTATE", {
		Receiver = TDMP.Enums.Receiver.ClientsOnly,
		Reliable = true,

		DontPack = false,
		Data = data
	})

end)

TDMP_RegisterEvent("TDMP_PHYSGUN_SETBEAM", function(rawdata, sender)
	--DebugPrint(rawdata)
	data = json.decode(rawdata)
	sender = (sender and sender ~= "" and sender) or data[2]
	--DebugPrint(data[1])
	playerPhysgunBeamEnabled[sender] = (data[1] == "1") or false
	if not TDMP_IsServer() then return end
	data[2] = sender
	TDMP_ServerStartEvent("TDMP_PHYSGUN_SETBEAM", {
		Receiver = TDMP.Enums.Receiver.ClientsOnly,
		Reliable = true,

		DontPack = false,
		Data = data
	})

end)

function TOOL:Initialize()

	
	self.mode = false
	self.scrolllock = 0

	self.world = {}
	if GetWorldBody then
		self.world[GetWorldBody()] = true
	end
	local allBodies = FindBodies( nil, true )
	local n, max_size = 0, 0
	for i, b in ipairs( allBodies ) do
		if not IsBodyDynamic( b ) then
			local min, max = GetBodyBounds( b )
			local size = VecLength( VecSub( max, min ) )
			if size > max_size and size < 1000000000 then
				n = i
				max_size = size
			end
		end
	end
	self.world[allBodies[n] or -1] = true
end

function TOOL:GetTarget()
	local ray = PLAYER:GetCamera():Raycast( 100, -1 )
	if not IsValid( ray.shape ) then
		return
	end
	local body = ray.shape:GetBody()

	if self.world[GetEntityHandle( body )] or ray.shape:HasTag( "ground" ) or body:HasTag( "ground" ) then
		return
	end

	return body, ray.hitpos, ray.dist
end

function TOOL:AttemptGrab()
	local body, hitpos, dist = self:GetTarget()
	if not body then
		return
	end
	local nwid =  TDMP_GetBodyNetworkId(body.handle) or -2
	if nwid == -2 then return end
	self.grabbed = body
	--self.grabbed:SetDynamic( true )
	--self.grabbed:SetVelocity( VEC_ZERO )
	local grtr = self.grabbed:GetTransform()
	self.relative = grtr:ToLocal( hitpos )
	self.rotation = PLAYER:GetTransform():ToLocal( self.grabbed:GetTransform() )
	self.clamped_rotation = nil
	state.dist = dist
	state.grabbed = self.grabbed
	state.relative = self.relative
	state.action = "pickup"

	if nwid and (nwid > 0) then
		TDMP_ClientStartEvent("TDMP_PHYSGUN_SETGRAB", {
			Reliable = true,
			DontPack = false, -- We don't have to send our steamId to the server cuz in TDMP 0.2.0 server already knows who sent event to it. 
			Data = {nwid, false}        -- So since Data is empty string, we don't need to pack it as json
		})
	end

	return self.grabbed
end


function TOOL:Primary()
	if not self:AttemptGrab() then
		self.grabbing = true
		state.grabbing = true
	end

	
end

function TOOL:Secondary()
	if self.grabbed then
		state.effect.freeze_time = GetTime()
		state.effect.freeze_body = self.grabbed
		ReleasePlayerGrab()
		--self.grabbed:SetVelocity( VEC_ZERO )
		--self.grabbed:SetAngularVelocity( VEC_ZERO )
		--self.grabbed:SetDynamic( false )
		self.grabbed = nil
		state.grabbed = nil
		state.action = "freeze"
		self.scrolllock = GetTime()
		TDMP_ClientStartEvent("TDMP_PHYSGUN_SETGRAB", {
			Reliable = true,
			DontPack = false, -- We don't have to send our steamId to the server cuz in TDMP 0.2.0 server already knows who sent event to it. 
			Data = {-2, true}        -- So since Data is empty string, we don't need to pack it as json
		})
	else
		self.mode = not self.mode
	end
end

function TOOL:PrimaryReleased()
	if self.grabbed then
		state.action = "drop"
	end
	self.grabbed = nil
	self.grabbing = false
	self.startrot = nil
	state.grabbed = nil
	state.grabbing = false
	TDMP_ClientStartEvent("TDMP_PHYSGUN_SETGRAB", {
		Reliable = true,
		DontPack = false, -- We don't have to send our steamId to the server cuz in TDMP 0.2.0 server already knows who sent event to it. 
		Data = {-2, false}        -- So since Data is empty string, we don't need to pack it as json
	})
end

function TOOL:MouseWheel( ds )
	if self.grabbed then
		state.dist = math.max( state.dist + ds, 2 )
		self.scrolllock = GetTime()
	end
end

function TOOL:ShouldLockMouseWheel()
	if self.grabbed or self.scrolllock > GetTime() - 0.5 then
		return true
	end
end

function TOOL:DrawBeam( source, target, object, r, g, b )
	if target == object then
		return DrawLine( source, target, r, g, b )
	end
	local prev = source
	for i = 1, 15 do
		local t = i / 16
		local t2 = t ^ 2
		local newpoint = source:Lerp( target, t2 ):Lerp( source:Lerp( object, t2 ), t2 )
		DrawLine( prev, newpoint, r, g, b )
		prev = newpoint
	end
	DrawLine( prev, object, r, g, b )
end

function getCustomToolPos(pl)
	local body = pl:GetToolBody()
	if body and body > 0 then
		local body_t = GetBodyTransform(body)
		return body_t.pos
	end
	return VecAdd(pl:GetPos(),  Vec(-0.8,1,1))
end

local lastgrabstate = false


local function VecClamp(bodyvelocity, maxVelocity)
	if VecLength(bodyvelocity) > maxVelocity then
		bodyvelocity = VecScale(bodyvelocity,(VecLength / maxVelocity) / 1)
		--[[if bodyvelocity.x > maxVelocity then bodyvelocity.x = maxVelocity end
		if bodyvelocity.y > maxVelocity then bodyvelocity.y = maxVelocity end
		if bodyvelocity.z > maxVelocity then bodyvelocity.z = maxVelocity end]]
	end
	return bodyvelocity
end
function TOOL:Tick()
	if self.grabbing ~= lastgrabstate then
		lastgrabstate = self.grabbing
		TDMP_ClientStartEvent("TDMP_PHYSGUN_SETBEAM",{
			Reliable = true,
			DontPack = false, -- We don't have to send our steamId to the server cuz in TDMP 0.2.0 server already knows who sent event to it. 
			Data = {( (self.grabbing and "1") or "0")}        -- So since Data is empty string, we don't need to pack it as json
		})
	end
	state.action = nil
	if GetBool( "game.player.canusetool" ) then
		if InputPressed(_lmb) then
			self:Primary()
		end
		if InputPressed(_rmb) then
			self:Secondary()
		end
		if InputReleased(_lmb) then
			self:PrimaryReleased()
		end
		if config.experimental.rotlock and InputPressed(config.key.rotlock) then
			self.disable_rot = not self.disable_rot
			if self.grabbed then
				self.startrot = nil
				self.rotation = PLAYER:GetTransform():ToLocal( self.grabbed:GetTransform() )
			end
		end
	end
	local camtr = PLAYER:GetCamera()

	if not self.grabbed or not self.grabbed:IsValid() then
		state.rotating = false
		if InputPressed( config.key.unfreeze ) then
			local body = self:GetTarget()
			if body then
				local nwid =  TDMP_GetBodyNetworkId(body.handle) or -2
				if nwid ~= -2 then
					--[[if not body:IsDynamic() then
						state.effect.unfreeze_time = GetTime()
						state.effect.unfreeze_body = body
						state.action = "unfreeze"
					end
					body:SetDynamic( true )
					body:SetVelocity( Vector( 0, 0, 0 ) )]]
					TDMP_ClientStartEvent("TDMP_PHYSGUN_UNFREEZE", {nwid})
				end
			end
		end

		if self.grabbing then
			if self:AttemptGrab() then
				self.grabbing = false
				state.grabbing = false
				return
			end
			if not InputDown( _lmb ) then
				self:PrimaryReleased()
			end
		end
		return
	end

	if InputPressed( config.key.throw ) then
		--DebugPrint("THROW")
		TDMP_ClientStartEvent("TDMP_PHYSGUN_THROW", {
			Reliable = true,
			DontPack = false, -- We don't have to send our steamId to the server cuz in TDMP 0.2.0 server already knows who sent event to it. 
			Data = {}        -- So since Data is empty string, we don't need to pack it as json
		})
		--[[self.grabbed:SetVelocity( camtr.rot:Forward() * -100 )
		self.grabbed = nil
		state.grabbed = nil]]
		state.action = "throw"
		return
	end


	if InputDown( config.key.rotate ) and not self.disable_rot then
		state.rotating = true
		if not self.startrot then
			self.startrot = self.rotation.rot
			self.mousex, self.mousey = 0, 0
			self.playerlock = GetPlayerTransform( true )
		end
		if config.legacy then
			UiMakeInteractive()
			local dx, dy = UiGetMousePos()
			local w, h = UiWidth(), UiHeight()
			dx, dy = dx - w / 2, dy - h / 2
			self.rotation.rot = QuatEuler( (dy - self.mousey) / h * 360, (dx - self.mousex) / w * 360, 0 ) * self.rotation.rot
			self.mousex, self.mousey = dx, dy
		else
			if GetWorldBody then
				SetBool( "game.player.disableinput", true )
			else
				SetPlayerTransform( self.playerlock, true )
			end
			local s = 500 * config.rotspeed / 6
			self.rotation.rot = QuatEuler( s * InputValue( "cameray" ), s * InputValue( "camerax" ), 0 ) * self.rotation.rot
		end

		if InputDown( "shift" ) and self.startrot then
			local nrot = PLAYER:GetTransform():ToGlobal( self.rotation )
			local lp, ly, lr = GetQuatEuler( nrot.rot )
			lp = math.floor( lp / 45 + .5 ) * 45
			ly = math.floor( ly / 45 + .5 ) * 45
			lr = math.floor( lr / 45 + .5 ) * 45
			self.clamped_rotation = MakeQuaternion( QuatEuler( lp, ly, lr ) )
		else
			self.clamped_rotation = nil
		end

		if InputPressed( _rmb ) then
			self:Secondary()
			return
		end
	else
		state.rotating = false
		self.startrot = nil
	end

	if true then
		local bodytr = self.grabbed:GetTransform()
		local onbody = bodytr:ToGlobal( self.relative )
		local aimpos = camtr:ToGlobal( Vector( 0, 0, -state.dist ) )

		--self.grabbed:SetVelocity( (aimpos - onbody) * 15 )
		local bodyvelocity = (aimpos - onbody) * 15
		local bodyangularvelocity = self.grabbed:GetAngularVelocity( )
		if not self.disable_rot then
			local rotation = self.clamped_rotation or PLAYER:GetTransform():ToGlobal( self.rotation ).rot

			local p, y, r = (bodytr.rot * rotation:Conjugate()):ToEuler()
			local diff = -Vector( p, y, r )

			--self.grabbed:SetAngularVelocity( diff / 5 )
			bodyangularvelocity = diff/5
		end
		--local body = self.grabbed:GetEntityHandle()
		local bodytransform = self.grabbed:GetTransform()
		--local bodyvelocity = self.grabbed:GetVelocity()

		--DebugCross(bodytransform.pos)
		--DebugPrint(bodytransform.rot[1])
		--DebugPrint(bodyvelocity[1])
		--DebugPrint(bodyangularvelocity[1])
		--bodyvelocity = VecClamp(bodyvelocity, 50)
		bodyangularvelocity = VecClamp(bodyangularvelocity, 50)

		local cooldata = {bodyvelocity, bodyangularvelocity} 
		local packed = json.encode(cooldata)
		--DebugPrint(packed)
		TDMP_ClientStartEvent("TDMP_PHYSGUN_SETPOS",{
			Reliable = true,
			DontPack = true, -- We don't have to send our steamId to the server cuz in TDMP 0.2.0 server already knows who sent event to it. 
			Data = packed    -- So since Data is empty string, we don't need to pack it as json
		})
		
	end

	if not InputDown( _lmb ) or GetPlayerVehicle() ~= 0 then
		self:PrimaryReleased()
	end
end

function TOOL:Update(dt)
	if true then
		if not self.grabbed or not self.grabbed:IsValid() then
			return
		end

		local bodytr = self.grabbed:GetTransform()
		local onbody = bodytr:ToGlobal( self.relative )
		local aimpos = PLAYER:GetCamera():ToGlobal( Vector( 0, 0, -state.dist ) )

		ConstrainPosition(self.grabbed.handle, 0, onbody, aimpos)

		if not self.disable_rot then
			local rotation = self.clamped_rotation or PLAYER:GetTransform():ToGlobal( self.rotation ).rot
			ConstrainOrientation(self.grabbed.handle, 0, bodytr.rot, rotation)
		end
	end

	if false and TDMP_IsServer() then
		for _, pl in ipairs(TDMP_GetPlayers()) do
			pl = Player(pl)
			if (pl.steamId ~= TDMP_LocalSteamID) then 
			    if playerStates[pl.steamId] and playerStates[pl.steamId][2] and playerStates[pl.steamId][2] > 0 and IsHandleValid(layerStates[pl.steamId][2]) then
				local camtr = pl:GetCamera()
				local dir = pl:GetAimDirection(camtr)
				local pl_pos = getCustomToolPos(pl)

				local pos = GetBodyTransform(playerStates[pl.steamId][2]).pos
				local hit, dist, normal, shape = QueryRaycast( camtr.pos , dir, 100,0, false) 
				if not hit then dist = 100 end
				local hitPoint = VecAdd(camtr.pos, VecScale(dir, dist))
				TOOL:DrawBeam(pl_pos, pos,pos,r,g,b)
				end


				local bodytr = self.grabbed:GetTransform()
				local onbody = bodytr:ToGlobal( self.relative )
				local aimpos = PLAYER:GetCamera():ToGlobal( Vector( 0, 0, -state.dist ) )

				ConstrainPosition(self.grabbed.handle, 0, onbody, aimpos)
			end
		end
	end

end

RegisterToolUMF( "physgun", TOOL, config.bottom )
function firsttick()
	if not GetBool( "game.tool.physgun.enabled" ) then
		TOOL.noregister = false
		RegisterToolUMF( "physgun", TOOL, config.bottom )
	end
end

function TDMP_DrawPlayerPhysguns()
	local r, g, b = math.random(), math.random(), math.random()
	for _, pl in ipairs(TDMP_GetPlayers()) do
		pl = Player(pl)

		if (pl.steamId ~= TDMP_LocalSteamID) then 
			--DebugPrint(pl:CurrentTool())
			--[[if (pl:GetToolBody() > 0) and pl:CurrentTool() == "physgun" then
				local toolbody = pl:GetToolBody()
				local toolshapes = GetBodyShapes(toolbody)
				TOOL:Animate(toolbody, toolshapes)
			end]]
			if playerPhysgunBeamEnabled[pl.steamId] then
				local camtr = pl:GetCamera()
				local dir = pl:GetAimDirection(camtr)
				
				local pl_pos = getCustomToolPos(pl)
				PointLight(pl_pos,r,g,b, 0.2)
				
				local hit, dist, normal, shape = QueryRaycast( camtr.pos , dir, 100,0, false) 
				if not hit then dist = 100 end
				local hitPoint = VecAdd(camtr.pos, VecScale(dir, dist))
				TOOL:DrawBeam(pl_pos, hitPoint,hitPoint,r,g,b)
			elseif playerStates[pl.steamId] and playerStates[pl.steamId][2] and playerStates[pl.steamId][2] > 0 then
				local camtr = pl:GetCamera()
				local dir = pl:GetAimDirection(camtr)
				local pl_pos = getCustomToolPos(pl)
				PointLight(pl_pos,r,g,b, 0.2)
				local pos = GetBodyTransform(playerStates[pl.steamId][2]).pos
				local hit, dist, normal, shape = QueryRaycast( camtr.pos , dir, 100,0, false) 
				if not hit then dist = 100 end
				local hitPoint = VecAdd(camtr.pos, VecScale(dir, dist))
				TOOL:DrawBeam(pl_pos, pos,pos,r,g,b)
			end
		end
		
	end
end
function tick()
	TDMP_DrawPlayerPhysguns()
end

function init()
	TDMP_AddToolModel("physgun", {
		xml='<body><vox pos="-0.6, 0.35, -0.9" file="MOD/vox/physgun.vox" scale="0.5"/></body>',
		offset = Vec(0,0,0), -- Moving tool position itself (i.e. where hands reach to), including tool body too
		--leftHandTarget = Vec(-0.6, 0.25, -0.9),-- Moving tool position itself (i.e. where hands reach to), including tool body too
		leftElbowBias = Transform(Vec(.5, 1, .3)), -- Optional. Sets target which left elbow will try to reach to. Set it to nil or remove entire field to keep it as default value
		--rightElbowBias = Transform(Vec(-.5, 1, 5)), -- Optional. Sets target which right elbow will try to reach to. Set it to nil or remove entire field to keep it as default value
		useBothHands = true, -- If true, then both hands are reaching to tool's position, if false, then only right hand would be used
	})
end
