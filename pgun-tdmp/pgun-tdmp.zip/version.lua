
MOD_VERSION = "1.1.1"
DEFAULT_SKIN = "main_default"

local function vlt( v1, v2 )
	local maj1, min1, patch1 = v1:match( "(%d+)%.(%d+)%.(%d+)" )
	local maj2, min2, patch2 = v2:match( "(%d+)%.(%d+)%.(%d+)" )
	return maj1 < maj2 or (maj1 == maj2 and min1 < min2 or (patch1 < patch2))
end

local savedversion = HasKey( "savegame.mod.version" ) and GetString( "savegame.mod.version" ) or "1.0.1"
SetString( "savegame.mod.version", MOD_VERSION )

-- Version logic

local event_skin = true

if savedversion ~= MOD_VERSION then
	if event_skin then
		if HasKey( "savegame.mod.skin" ) then
			SetString( "savegame.mod.skin.backup", GetString( "savegame.mod.skin" ) )
		end
		ClearKey( "savegame.mod.skin" )
	else
		if not HasKey( "savegame.mod.skin" ) and GetString( "savegame.mod.skin.backup" ) ~= "" then
			SetString( "savegame.mod.skin", GetString( "savegame.mod.skin.backup" ) )
		end
		ClearKey( "savegame.mod.skin.backup" )
	end
end