visible = 0

function init()
	SetValue("visible", 1.0, "cosine", 0.5)
end

function tick()
	--Put a scripting menu button on the pause menu for all levels, except the main menu
	if not string.find(GetString("game.levelpath"), "main.xml") then
		if PauseMenuButton("Scripting Showcase Menu") then
			StartLevel("", "MOD/main.xml")
		end
	end
end


function draw()	
	local path = GetString("game.levelpath")
	if string.find(path, "lightswitch.xml") then
		infoBox("This example shows an interactable light switch which turns a light on and off. You can find the script in script/lightswitch.lua.\n\nThe red button uses the interact tag which will make an interact notification show up. By changing the value of the interact tag from the script it is possible to display a different text for turning on and turning off the light.")
	elseif string.find(path, "radio.xml") then
		infoBox("A radio you can turn on or off. It is similar to the light switch, but will also react to the radio being broken. The script is located in script/radio.lua")
	elseif string.find(path, "elevator.xml") then
		infoBox("There are many pitfalls when making an elevator script. Take into consideration that the player might want to abort the current motion, switch direction while moving and that the elevator can get stuck on dynamic objects. Here is an example implementation using a prismatic joint and the SetJointMotorTarget function. You can find the code in script/elevator.lua")
	elseif string.find(path, "laser.xml") then
		infoBox("This example shows how the QueryRaycast function can be used to implement a laser beam. Light flashes and particle effects are used when an object is hit. After a few moments, the MakeHole function is called to carve out a hole in the hit object. The code is available in script/laser.lua")
	elseif string.find(path, "turret.xml") then
		infoBox("A turret that will turn towards the player and shoot when player is visible. The turrent uses a raycast to determine if player is visible and SetJointMotor to turn the turret. The code for this example can be found in script/turret.lua")
	elseif string.find(path, "forcefield.xml") then
		infoBox("This example showcase a fan that applies force to dynamic bodies. A scene query is used to collect shapes from the environment and impulses are applied to the corresponding bodies. The code is in script/forcefield.lua")
	elseif string.find(path, "weather.xml") then
		infoBox("A dynamic weather cycle going from rain to clear sky and back again. The code can be found in script/weather.lua")
	elseif string.find(path, "flyover.xml") then
		infoBox("A camera flyover by interpolating the camera transform between two location transforms. The code can be found in script/flyover.lua")
	elseif string.find(path, "savegame.xml") then
		infoBox("Shoot the barrels to increase score. Try running this example twice to see that the persistent score is remembered even if the game is restarted. The code for each barrel can be found in script/savegame-target.lua and the code that reads back the score and prints it on the screen is in script/savegame-display.lua")
	elseif string.find(path, "pathfinding.xml") then
		infoBox("This example uses path queries to find a walkable path from the blue box to the green box. Try moving the boxes and modify the environment to see how the resulting path adapts to the new conditions. Path finding queries asynchronous. This means you have to initiate a query, let it run in the background and retrieve the result several frames or even seconds later.")
	elseif string.find(path, "constraints.xml") then
		infoBox("Constraints are used to animate bodies physically. It is similar to using joint motors but gives much more control and allows for more complex animations. The left example animates a single body to the static environment. The right one animates the feet relative the body to create a walking animation. See script/constraints.lua and script/walker.lua")
	elseif string.find(path, "spawning.xml") then
		infoBox("Spawning can be used to add new entities to an existing scene. The Spawn function can either read an existing prefab XML file or it can spawn from a lua string with XML content. The Spawn function is normally used for spawning in dynamic bodies, but it can also be used to add static geometry to the existing scene. See script/spawning.lua for details.")
	else
		--Print message about making a local copy only if it's not already a local copy
		local localMsg = ""
		if string.sub(GetString("game.mod"), 0, 5) ~= "local" then
			localMsg = "Welcome to the scripting showcase. We recommend making a local copy of this mod so you can more easily view and alter the scripts it uses. "
		end
		infoBox(localMsg .. "This is the showcase menu. It consists of a simple scene and a script that lets you select different levels. The script for this menu is script/menu.lua. This scene is defined in the default level file main.xml.\n\nThis text is added by main.lua, which is always running on all levels in this mod. The main.lua script figures out which level you are running and displays a different message for each one. It also adds a button on the pause menu to get back to this main menu.")
	end
end


function infoBox(txt)
	UiPush()
		UiFont("regular.ttf", 22)
		UiWordWrap(500)

		local w,h = UiGetTextSize(txt)
		UiTranslate(20-600*(1-visible), UiHeight()-h-50)
		UiColor(0,0,0, 0.7)
		UiImageBox("ui/common/box-solid-10.png", w+40, h+30, 10, 10)
		UiTranslate(20, 35)
		
		UiColor(1,1,1)
		UiText(txt)
	UiPop()
end
