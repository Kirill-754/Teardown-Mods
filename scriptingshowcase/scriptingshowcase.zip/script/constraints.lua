--This example constrains the position and orientation of one body to an animated target in 
--the static environment. Joints that are attached to the animated body will follow along the
--animation physically

function init()	
	--Find handle the the head body
	headBody = FindBody("head")

	--Find the base position for the animation
	markerPos = GetLocationTransform(FindLocation("marker")).pos
end


function update(dt)
	--Maximum speed and strength that can be applied to the head
	local maxSpeed = 10
	local strength = 100

	--Current head transform
	local t = GetBodyTransform(headBody)

	--Physically constrain position of the head
	local x = math.cos(GetTime()) * 0.7
	local y = math.sin(GetTime()*1.7)*0.5
	local z = math.sin(GetTime()) * 0.7
	local targetPos = VecAdd(markerPos, Vec(x, y, z))
	ConstrainPosition(headBody, 0, t.pos, targetPos, maxSpeed, strength) 

	--Phyiscally constrain the orientation of the head
	local targetRot = QuatEuler(0, 50*math.sin(GetTime()*1.4), 0)
	ConstrainOrientation(headBody, 0, t.rot, targetRot, maxSpeed, strength)
end



