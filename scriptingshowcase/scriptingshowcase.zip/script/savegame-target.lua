function init()
	shape = FindShape()
	done = false
	scoreSound = LoadSound("pickup.ogg")
end


function tick()
	if not done and IsShapeBroken(shape) then
		PlaySound(scoreSound)

		--Increment the session score
		local score = GetInt("level.score")
		SetInt("level.score", score + 1)

		--Increment the savegame score
		local savedScore = GetInt("savegame.mod.score")
		SetInt("savegame.mod.score", savedScore + 1)
		
		done = true
	end
end

