function draw()	
	UiMakeInteractive()
	
	UiPush()
		UiAlign("center middle")
		UiFont("bold.ttf", 32)

		UiTranslate(UiCenter(), 200)
		UiPush()
			UiScale(3)
			UiText("Scripting Showcase")
		UiPop()
		
		UiTranslate(-90, 100)
		
		UiAlign("left")
		
		if UiTextButton("Light switch") then StartLevel("", "MOD/lightswitch.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Radio") then StartLevel("", "MOD/radio.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Elevator") then StartLevel("", "MOD/elevator.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Laser") then StartLevel("", "MOD/laser.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Turret") then StartLevel("", "MOD/turret.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Forcefield") then StartLevel("", "MOD/forcefield.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Dynamic weather") then StartLevel("", "MOD/weather.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Flyover") then StartLevel("", "MOD/flyover.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Savegame") then StartLevel("", "MOD/savegame.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Path finding") then StartLevel("", "MOD/pathfinding.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Constraints") then StartLevel("", "MOD/constraints.xml") end
		UiTranslate(0, 32)

		if UiTextButton("Spawning") then StartLevel("", "MOD/spawning.xml") end
		UiTranslate(0, 32)
	UiPop()
end
