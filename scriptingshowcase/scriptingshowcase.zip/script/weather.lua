function tick(dt)
	--Animate between zero and one
	local t = math.sin(GetTime()*0.4) * 1.5
	if t < 0.0 then t = 0.0 end
	if t > 1.0 then t = 1.0 end

	local wet = t
	local dry = 1.0-t
	
	--Rain and ground wetness
	SetEnvironmentProperty("rain", wet)
	SetEnvironmentProperty("wetness", wet*0.5)
	SetEnvironmentProperty("puddleamount", wet*0.5)

	--Rain ambience sound when raining
	SetEnvironmentProperty("ambience", "outdoor/rain_light.ogg", wet)
	
	--Darker and thicker fog when raining
	SetEnvironmentProperty("fogcolor", 0.1+0.9*dry, 0.1+0.9*dry, 0.1+0.9*dry)
	SetEnvironmentProperty("fogparams", 0, 20+80*dry, 0.95, 1+2*dry)

	--Brighter skybox and sun when dry
	SetEnvironmentProperty("skyboxbrightness", 0.5 + dry*2.0)
	SetEnvironmentProperty("sunbrightness", dry)
	SetEnvironmentProperty("sunglare", dry)

	--Rotate skybox continuously
	SetEnvironmentProperty("skyboxrot", GetTime())
end


