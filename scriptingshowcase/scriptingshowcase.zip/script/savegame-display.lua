function draw()
	UiFont("bold.ttf", 24)
	UiTranslate(UiCenter()-100, 100)
	UiText("Session score: " .. GetInt("level.score"))
	UiTranslate(0, 24)
	UiText("Total score: " .. GetInt("savegame.mod.score"))
end
