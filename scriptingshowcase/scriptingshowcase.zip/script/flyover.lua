function init()	
	local l0 = FindLocation("start")
	local l1 = FindLocation("end")
	
	t0 = GetLocationTransform(l0)
	t1 = GetLocationTransform(l1)
	
	t = 0
end


function tick(dt)
	t = t + dt
	if t > 10 then
		t = 0
	end
	
	--Linear interpolation between t0 and t1
	local q = t / 10
	local pos = VecLerp(t0.pos, t1.pos, q)
	local rot = QuatSlerp(t0.rot, t1.rot, q)
	
	--Set camera transform, this will override the default camera for this frame
	SetCameraTransform(Transform(pos, rot))

	--Disable player input during the camera flyover
	SetBool("game.disableinput", true)
end


function draw()
	--Add letterbox black bars at top and bottom
	UiColor(0,0,0)
	UiRect(UiWidth(), 120)
	UiTranslate(0, UiHeight()-120)
	UiRect(UiWidth(), 120)
end

