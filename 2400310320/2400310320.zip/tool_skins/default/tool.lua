--[[
#include "../../umf.lua"
]] --

local state = util.structured_table( "game.tool.physgun", {
	bottom = "boolean",
	grabbed = "body",
	grabbing = "boolean",
	relative = "vector",
	dist = "number",
	effect = {
		freeze_time = "number",
		freeze_body = "body",
		unfreeze_time = "number",
		unfreeze_body = "body",
	},
	skin = {
		config = {
			outline = { "boolean", true },
			beam = { "boolean", true },
			freeze = { "boolean", true },
			tool = { "boolean", true },
			sound = { "boolean", true },
		}
	}
} )

local isFloppy = GetBoolParam("floppy", false)

local TOOL = {}

TOOL.printname = isFloppy and "Floppy Gun" or "Physics Gun"

function TOOL:Initialize()
	self.motor_fast = LoadLoop( "MOD/sound/motor_fast.ogg" )
	self.motor_med = LoadLoop( "MOD/sound/motor_med.ogg" )
end

local function clamp( n, min, max )
	return math.min( math.max( n, min ), max )
end
local function steps( x, bounce )
	return x - math.abs( math.sin( x * math.pi ) / (math.pi - bounce) )
end
local function approach( c, t, m, mn )
	return c + math.max( math.min( t - c, m ), mn or -m )
end

local toolpos = Transform( Vec( 8.5 / 20, -7.5 / 20, -6 / 20 - 0.25 + (state.skin.config.tool and 0 or 2) ),
                           QuatEuler( 0, 0, 0 ) )
function TOOL:Update()
	SetToolTransform( toolpos )
end
local deploy_time = 0
local anim_data = { core = { { 0, 0 }, { 0, 0 }, { 0, 0 } }, arms = 0, rot = { 0, 0, 0 } }
local speedmod = { 1, 1.1, 1.05 }
function TOOL:Animate( body, shapes )
	SetToolTransform( toolpos )
	local armature = self.armature
	local dt = GetTimeStep()

	local arm_base_offset = 0
	local arm_tip_offset = 0
	if deploy_time < 3 then
		local stepf = steps( deploy_time * 2.7, 1.5 )

		local a, b = clamp( stepf, 0, 1 ), clamp( stepf, 1, 2 ) - 1
		local deploy = steps( clamp( 1 - deploy_time * 3, 0, 1 ), 0.8 )

		armature:SetBoneTransform( "root", Transform( Vec( 0, deploy * -0.2, 0 ), QuatEuler( deploy * -20, 0, 0 ) ) )

		armature:SetBoneTransform( "spine1", Transform( Vec( 0, 0, 0.1 - a / 10 ), QuatEuler( 0, 0, 0 ) ) )
		armature:SetBoneTransform( "spine2", Transform( Vec( 0, 0, 0.1 - b / 10 ), QuatEuler( 0, 0, 0 ) ) )

		arm_base_offset = 50 * a - 50
		arm_tip_offset = 90 * b - 90
	end
	local ang = state.grabbing and -20 or state.grabbed and -90 or -40
	local rand = state.grabbing and 6 or state.grabbed and 4 or 0
	anim_data.arms = approach( anim_data.arms, ang, 720 * dt )
	local a1, a2, a3 = anim_data.arms + (math.random() - 0.5) * rand, anim_data.arms + (math.random() - 0.5) * rand,
	                   anim_data.arms + (math.random() - 0.5) * rand

	if state.grabbing then
		anim_data.rot[2] = anim_data.rot[2] + dt * 200
		anim_data.rot[3] = GetTime() + 1
	elseif state.grabbed then
		anim_data.rot[2] = anim_data.rot[2] - dt * 100
		anim_data.rot[3] = GetTime() + 1
	elseif anim_data.rot[3] < GetTime() then
		local rt = (1 - math.random() ^ 3)
		anim_data.rot[3] = GetTime() + rt * 2
		anim_data.rot[2] = anim_data.rot[2] + (1 - rt) * (math.random() * 720 - 360)
	end
	if math.abs( anim_data.rot[1] - anim_data.rot[2] ) > 0.001 and state.skin.config.sound then
		PlayLoop( state.grabbed and self.motor_med or self.motor_fast, body:GetTransform().pos,
		          state.grabbed and 0.3 or state.grabbing and 0.2 or 1 )
	end
	anim_data.rot[1] = approach( anim_data.rot[1], anim_data.rot[2], 720 * dt )
	armature:SetBoneTransform( "arms_rot", Transform( Vec(), QuatEuler( 0, 0, anim_data.rot[1] ) ) )

	armature:SetBoneTransform( "arm0_base", Transform( Vec(), QuatEuler( a1 + arm_base_offset, 0, 0 ) ) )
	armature:SetBoneTransform( "arm0_tip", Transform( Vec(), QuatEuler( a2 + arm_tip_offset, 0, 0 ) ) )

	armature:SetBoneTransform( "arm1_base", Transform( Vec(), QuatEuler( a2 + arm_base_offset, 0, 0 ) ) )
	armature:SetBoneTransform( "arm1_tip", Transform( Vec(), QuatEuler( a3 + arm_tip_offset, 0, 0 ) ) )

	armature:SetBoneTransform( "arm2_base", Transform( Vec(), QuatEuler( a3 + arm_base_offset, 0, 0 ) ) )
	armature:SetBoneTransform( "arm2_tip", Transform( Vec(), QuatEuler( a1 + arm_tip_offset, 0, 0 ) ) )

	local warmth = math.min( deploy_time, 10 ) / 10
	local speed = state.grabbing and 360 or state.grabbed and 520 or 120
	for i = 1, 3 do
		if deploy_time > i / 2 then
			anim_data.core[i][1] = approach( anim_data.core[i][1], speed * speedmod[i], warmth * 500 * dt, -200 * dt )
			anim_data.core[i][2] = anim_data.core[i][2] + anim_data.core[i][1] * dt * ((i % 2) * 2 - 1)
		end
	end
	armature:SetBoneTransform( "core0", Transform( Vec( 0, 0, 0 ), QuatEuler( 0, 0, anim_data.core[1][2] ) ) )
	armature:SetBoneTransform( "core1", Transform( Vec( 0, 0, 0 ), QuatEuler( 0, 0, anim_data.core[2][2] ) ) )
	armature:SetBoneTransform( "core2", Transform( Vec( 0, 0, 0 ), QuatEuler( 0, 0, anim_data.core[3][2] ) ) )

	local lit = (anim_data.core[1][1] / 520) ^ 2
	for i = 1, #shapes do
		shapes[i]:SetEmissiveScale( lit )
	end

	deploy_time = deploy_time + 1.5 * dt
end

function TOOL:Deploy()
	deploy_time = 0
	anim_data = { core = { { 0, 0 }, { 0, 0 }, { 0, 0 } }, arms = 0, rot = { 0, 0, GetTime() + 1.5 } }
	if isFloppy then
		local wobble = 2
		local wobble_constraint = {gravity = 0.3}
		self.armature:SetBoneJiggle("spine0", wobble, wobble_constraint)
		self.armature:SetBoneJiggle("spine1", wobble, wobble_constraint)
		self.armature:SetBoneJiggle("spine2", wobble, wobble_constraint)
		self.armature:SetBoneJiggle("spine3", wobble, wobble_constraint)
		self.armature:SetBoneJiggle("arm0_base", wobble * 3, wobble_constraint)
		self.armature:SetBoneJiggle("arm0_tip", wobble * 5, wobble_constraint)
		self.armature:SetBoneJiggle("arm1_base", wobble * 3, wobble_constraint)
		self.armature:SetBoneJiggle("arm1_tip", wobble * 5, wobble_constraint)
		self.armature:SetBoneJiggle("arm2_base", wobble * 3, wobble_constraint)
		self.armature:SetBoneJiggle("arm2_tip", wobble * 5, wobble_constraint)
	end
end

function TOOL:DrawBeam( source, target, object, r, g, b )
	if target == object then
		return DrawLine( source, target, r, g, b )
	end
	local prev = source
	for i = 1, 15 do
		local t = i / 16
		local t2 = t ^ 2
		local newpoint = source:Lerp( target, t2 ):Lerp( source:Lerp( object, t2 ), t2 )
		DrawLine( prev, newpoint, r, g, b )
		prev = newpoint
	end
	DrawLine( prev, object, r, g, b )
end

local function effect_t(time, duration)
	if not time then return end
	local t = (GetTime() - time) / duration
	if t >= 0 and t <= 1 then return t end
end

function TOOL:Tick()
	local freeze = effect_t(state.effect.freeze_time, 1)
	if freeze then
		local body = state.effect.freeze_body
		body:DrawHighlight( .5 - freeze / 2 )
		body:DrawOutline( freeze, .5 + freeze / 2, 1, 1 - freeze )
	end
	local unfreeze = effect_t(state.effect.unfreeze_time, 1)
	if unfreeze then
		local body = state.effect.unfreeze_body
		body:DrawHighlight( .5 - unfreeze / 2 )
		body:DrawOutline( 1, .5 + unfreeze / 2, unfreeze, 1 - unfreeze )
	end

	local r, g, b = math.random(), math.random(), math.random()
	local camtr = PLAYER:GetCamera()
	local nozzletr = self:GetBoneGlobalTransform( "nozzle" )
	local nozzle = nozzletr.pos

	if not state.grabbed or not state.grabbed:IsValid() then
		if state.grabbing then
			local ray = camtr:Raycast( 100, -1 )
			if state.skin.config.beam then
				self:DrawBeam( nozzle, nozzletr:ToGlobal( Vector( 0, 0, -ray.dist / 2 ) ), ray.hitpos, r, g, b )
			end
			if state.skin.config.tool then
				PointLight( nozzle, r, g, b, .1 )
			end
		end
		return
	end

	local bodytr = state.grabbed:GetTransform()
	local onbody = bodytr:ToGlobal( state.relative )
	local aimpos = camtr:ToGlobal( Vector( 0, 0, -state.dist ) )

	if state.skin.config.outline then
		state.grabbed:DrawOutline( r, g, b, 1 )
	end
	if state.skin.config.beam then
		self:DrawBeam( nozzle, nozzletr:ToGlobal( Vector( 0, 0, -state.dist / 2 ) ), onbody, r, g, b )
	end
	if state.skin.config.tool then
		PointLight( nozzle, r, g, b, .2 )
	end
end

--[[local function draw3dline(p1, p2, r, g, b, a)
	local tr = PLAYER:GetCamera()
	local p1_l, p2_l = tr:ToLocal(p1), tr:ToLocal(p2)
	if p1_l[3] > -0.1 and p2_l[3] > -0.1 then return end
	if p2_l[3] > -0.1 then p1, p2, p1_l, p2_l = p2, p1, p2_l, p1_l end
	if p1_l[3] > -0.1 then
		p1 = VecLerp(p1, p2, (p1_l[3] + 0.1) / (p1_l[3] - p2_l[3]))
	end
	local p1_x, p1_y = UiWorldToPixel(p1)
	local p2_x, p2_y = UiWorldToPixel(p2)
	
	UiPush()
		UiAlign("center middle")
		UiTranslate((p1_x+p2_x)/2, (p1_y+p2_y)/2)
		UiRotate(math.deg(math.atan2(p2_x-p1_x, p2_y-p1_y)))
		UiColor(r, g, b, a)
		UiRect(2,math.sqrt((p2_x-p1_x)^2+(p2_y-p1_y)^2))
	UiPop()
end
DebugLine = draw3dline

function TOOL:Draw()
	self:DrawDebug()
	--draw3dline(Vector(0,0,0), self:GetBoneGlobalTransform( "nozzle" ).pos, 1, 0, 0, 1)
end]]

TOOL.model = {
	prefab = [[
		<prefab version="0.9.2">
            <group name="instance=MOD/physgun.xml" pos="-3.5 0.9 9.1" rot="0.0 0.0 0.0">
                <vox pos="-0.125 -0.125 0.125" file="MOD/vox/physgun.vox" object="body" scale="0.5"/>
                <group name="spine0" pos="0.0 0.0 -0.025">
                    <group name="core0" pos="0.0 0.0 0.0" rot="0.0 0.0 0.0">
                        <vox pos="-0.025 -0.125 -0.05" rot="0.0 0.0 0.0" file="MOD/vox/physgun.vox" object="core_0" scale="0.5"/>
                    </group>
                    <group name="spine1" pos="0.0 0.0 -0.1">
                        <group name="core1" pos="0.0 0.0 0.0" rot="0.0 0.0 0.0">
                            <vox pos="-0.025 -0.125 -0.05" rot="0.0 0.0 0.0" file="MOD/vox/physgun.vox" object="core_1" scale="0.5"/>
                        </group>
                        <group name="spine2" pos="0.0 0.0 -0.1">
                            <group name="core2" pos="0.0 0.0 0.0" rot="0.0 0.0 0.0">
                                <vox pos="-0.025 -0.125 -0.05" rot="0.0 0.0 0.0" file="MOD/vox/physgun.vox" object="core_2" scale="0.5"/>
                            </group>
                            <group name="spine3" pos="0.0 0.0 -0.1" rot="0.0 0.0 0.0">
                                <vox pos="-0.025 -0.125 -0.05" rot="0.0 0.0 0.0" file="MOD/vox/physgun.vox" object="cannon" scale="0.5"/>
                                <location name="nozzle" pos="0.0 0.0 -0.15" rot="0.0 0.0 0.0"/>
                                <group name="arms_rot" pos="0.0 0.0 -0.05" rot="0.0 0.0 0.0">
                                    <group name="arm0_base" pos="0.0 0.1 0.0" rot="90.0 0.0 0.0">
                                        <vox pos="-0.025 0.025 0.05" rot="-90.0 0.0 0.0" file="MOD/vox/physgun.vox" object="arm_00" scale="0.5"/>
                                        <group name="arm0_tip" pos="0.0 0.0 -0.2" rot="0.0 0.0 0.0">
                                            <vox pos="-0.025 0.025 0.0" rot="-90.0 0.0 0.0" file="MOD/vox/physgun.vox" object="arm_01" scale="0.5"/>
                                        </group>
                                    </group>
                                    <group name="arm1_base" pos="-0.087 -0.05 0.0" rot="-90.0 180.0 60.0">
                                        <vox pos="-0.025 0.025 0.05" rot="-90.0 0.0 0.0" file="MOD/vox/physgun.vox" object="arm_10" scale="0.5"/>
                                        <group name="arm1_tip" pos="0.0 0.0 -0.2" rot="0.0 0.0 0.0">
                                            <vox pos="-0.025 0.025 0.0" rot="-90.0 0.0 0.0" file="MOD/vox/physgun.vox" object="arm_11" scale="0.5"/>
                                        </group>
                                    </group>
                                    <group name="arm2_base" pos="0.087 -0.05 0.0" rot="-90.0 -180.0 -60.0">
                                        <vox pos="-0.025 0.025 0.05" rot="-90.0 0.0 0.0" file="MOD/vox/physgun.vox" object="arm_20" scale="0.5"/>
                                        <group name="arm2_tip" pos="0.0 0.0 -0.2" rot="0.0 0.0 0.0">
                                            <vox pos="-0.025 0.025 0.0" rot="-90.0 0.0 0.0" file="MOD/vox/physgun.vox" object="arm_21" scale="0.5"/>
                                        </group>
                                    </group>
                                </group>
                            </group>
                        </group>
                    </group>
                </group>
            </group>
        </prefab>
	]],
	objects = {
		{ "cannon", Vec( 5, 3, 5 ) },
		{ "core_2", Vec( 5, 2, 5 ) },
		{ "core_1", Vec( 5, 2, 5 ) },
		{ "core_0", Vec( 5, 2, 5 ) },
		{ "arm_21", Vec( 1, 1, 2 ) },
		{ "arm_11", Vec( 1, 1, 2 ) },
		{ "arm_01", Vec( 1, 1, 2 ) },
		{ "arm_20", Vec( 1, 1, 5 ) },
		{ "arm_10", Vec( 1, 1, 5 ) },
		{ "arm_00", Vec( 1, 1, 5 ) },
		{ "body", Vec( 9, 6, 5 ) },
	},
}

RegisterToolUMF( "physgun", TOOL, state.bottom )
