return {
	main_default = {
		name = "Default",
		desc = "The normal Physgun you know and love.",
		main = "MOD/tool_skins/default/tool.xml",
		icon = "MOD/tool_skins/default/icon.jpg",
		config = {
			outline = { name = "Prop Outline", type = "checkbox", default = true },
			beam = { name = "Beam", type = "checkbox", default = true },
			freeze = { name = "Freeze / Unfreeze", type = "checkbox", default = true },
			tool = { name = "Tool Model", type = "checkbox", default = true },
			sound = { name = "Sounds", type = "checkbox", default = true },
		},
		sort = 0,
	},
	main_april_fools = {
		name = "Floppy Gun",
		desc = "It seems this one is feeling a bit down...\n(April Fools 2022)",
		main = "MOD/tool_skins/floppy/tool.xml",
		icon = "MOD/tool_skins/floppy/icon.jpg",
		config = {
			outline = { name = "Prop Outline", type = "checkbox", default = true },
			beam = { name = "Beam", type = "checkbox", default = true },
			freeze = { name = "Freeze / Unfreeze", type = "checkbox", default = true },
			tool = { name = "Tool Model", type = "checkbox", default = true },
			sound = { name = "Sounds", type = "checkbox", default = true },
		},
		sort = 0.1,
	},
	main_halloween = {
		name = "Psychic Gun",
		desc = "Wait where's the gun?\n(Halloween 2022)",
		main = "MOD/tool_skins/halloween/tool.xml",
		icon = "MOD/tool_skins/halloween/icon.jpg",
		sort = 0.2,
	}
}