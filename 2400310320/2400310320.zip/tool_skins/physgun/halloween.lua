--[[
#include "../../umf.lua"
]] --

local state = util.structured_table( "game.tool.physgun", {
	bottom = "boolean",
	grabbed = "body",
	grabbing = "boolean",
	relative = "vector",
	dist = "number",
	action = "string",
	rotating = "boolean",
	effect = {
		freeze_time = "number",
		freeze_body = "body",
		unfreeze_time = "number",
		unfreeze_body = "body",
	}
} )

local TOOL = {}

TOOL.printname = "Psychic Gun"

function TOOL:Initialize()
	self.hum_low = LoadLoop( "MOD/sound/hum_low.ogg" )
	self.hum_high = LoadLoop( "MOD/sound/hum_high.ogg" )
	self.click1 = LoadSound( "MOD/sound/click1.ogg" )
	self.click2 = LoadSound( "MOD/sound/click2.ogg" )
	self.hit = LoadSound( "MOD/sound/hit.ogg" )
end

local function approach( c, t, m, mn )
	return c + math.max( math.min( t - c, m ), mn or -m )
end

local function approach_vec( c, t, m, mn )
	return Vec(
		c[1] * (1 - m) + t[1] * m,
		c[2] * (1 - m) + t[2] * m,
		c[3] * (1 - m) + t[3] * m
	)
end

local function approach_pose( current, target, m )
	for k, v in pairs(target) do
		current[k] = approach_vec( current[k] or v, v, m )
	end
end

local function lerp_pose( poseA, poseB, t )
	local new = {}
	for k, v in pairs( poseA ) do
		new[k] = VecLerp( v, poseB[k], t )
	end
	return new
end

local function edit_pose( pose, bone, added )
	pose[bone] = VecAdd( pose[bone], added )
end

local pose_list = {
	default = {
		{
			tool_pos = Vec( 8.5 / 20, -0.8, 0 ),
			--tool_rot = Vec( 50, 0, 0 ),
			--wrist = Vec(-28, -21, -130),
			tool_rot = Vec( 50, 0, 0 ),
			wrist = Vec(16, -9, -43),
			f00 = Vec(5, 16, 0), f01 = Vec(-23), f02 = Vec(-16),
			f10 = Vec(-8, 6, 0), f11 = Vec(-10), f12 = Vec(-11),
			f20 = Vec(-10, 0, 0), f21 = Vec(-14), f22 = Vec(-20),
			f30 = Vec(-11, -5, 0), f31 = Vec(-16), f32 = Vec(-22),
			f40 = Vec(-14, -14, 0), f41 = Vec(-23), f42 = Vec(-28),
		},
		{
			tool_pos = Vec( 8.5 / 20, -7.5 / 20, 0 ),
			tool_rot = Vec( 7, 0, 0 ),
			wrist = Vec(65, 10, -23),
			f00 = Vec(11, 7, 0), f01 = Vec(-20), f02 = Vec(-8),
			f10 = Vec(-4, 3, 0), f11 = Vec(-4), f12 = Vec(-5),
			f20 = Vec(-8, 0, 0), f21 = Vec(-11), f22 = Vec(-17),
			f30 = Vec(-8, -3, 0), f31 = Vec(-13), f32 = Vec(-25),
			f40 = Vec(-14, -14, 0), f41 = Vec(-20), f42 = Vec(-20),
		},
	},
	grabbing = {
		{
			tool_pos = Vec( 8.5 / 20, -0.8, -0.1 ),
			tool_rot = Vec( 50, 0, 0 ),
			wrist = Vec(16, -20, -43),
			f00 = Vec(14, 16, 0), f01 = Vec(-8), f02 = Vec(-2),
			f10 = Vec(11, 10, 0), f11 = Vec(-1), f12 = Vec(-4),
			f20 = Vec(7, 0, 0), f21 = Vec(-1), f22 = Vec(-2),
			f30 = Vec(4, -11, 0), f31 = Vec(-2), f32 = Vec(-7),
			f40 = Vec(-1, -18, 0), f41 = Vec(-2), f42 = Vec(-5),
		},
		{
			tool_pos = Vec( 8.5 / 20, -7.5 / 20, 0 ),
			tool_rot = Vec( 7, 0, 0 ),
			wrist = Vec(65, 20, -23),
			f00 = Vec(14, 16, 0), f01 = Vec(-8), f02 = Vec(-2),
			f10 = Vec(11, 10, 0), f11 = Vec(-1), f12 = Vec(-4),
			f20 = Vec(7, 0, 0), f21 = Vec(-1), f22 = Vec(-2),
			f30 = Vec(4, -11, 0), f31 = Vec(-2), f32 = Vec(-7),
			f40 = Vec(-1, -18, 0), f41 = Vec(-2), f42 = Vec(-5),
		},
	},
	grabbed = {
		{
			tool_pos = Vec( 8.5 / 20, -0.8, 0 ),
			tool_rot = Vec( 50, 0, 0 ),
			wrist = Vec(-16, 9, -130),
			f00 = Vec(-7, 16, 9), f01 = Vec(-40), f02 = Vec(-90),
			f10 = Vec(-71, 3, -7), f11 = Vec(-74), f12 = Vec(-90),
			f20 = Vec(-67, 0, 0), f21 = Vec(-77), f22 = Vec(-90),
			f30 = Vec(-65, -11, 0), f31 = Vec(-80), f32 = Vec(-90),
			f40 = Vec(-53, -5, 21), f41 = Vec(-71), f42 = Vec(-90),
		},
		{
			tool_pos = Vec( 8.5 / 20, -7.5 / 20, 0.2 ),
			tool_rot = Vec( 7, 0, 0 ),
			wrist = Vec(47, 6, -29),
			f00 = Vec(-1, 21, 8), f01 = Vec(-22), f02 = Vec(-31),
			f10 = Vec(-22, 9, -1), f11 = Vec(-32), f12 = Vec(-25),
			f20 = Vec(-14, 0, 0), f21 = Vec(-19), f22 = Vec(-19),
			f30 = Vec(-10, -5, 0), f31 = Vec(-14), f32 = Vec(-19),
			f40 = Vec(4, -9, 0), f41 = Vec(-20), f42 = Vec(-23),
		},
	}
}

local breathing = {
	tool_pos = Vec( 0, 0.01, 0 ),
	tool_rot = Vec( 0.25, 0, 0 ),
	wrist = Vec(1, 0, 0),
	f00 = Vec(1, 2, 0), f01 = Vec(1), f02 = Vec(1),
	f10 = Vec(1, 1, 0), f11 = Vec(1), f12 = Vec(1),
	f20 = Vec(1, 0, 0), f21 = Vec(1), f22 = Vec(1),
	f30 = Vec(1, -1, 0), f31 = Vec(1), f32 = Vec(1),
	f40 = Vec(1, -2, 0), f41 = Vec(1), f42 = Vec(1),
}

local freeze = {
	f00 = Vec(14, 16, 0), f01 = Vec(-8), f02 = Vec(-2),
	f10 = Vec(11, 10, 0), f11 = Vec(-1), f12 = Vec(-4),
	f20 = Vec(7, 0, 0), f21 = Vec(-1), f22 = Vec(-2),
	f30 = Vec(4, -11, 0), f31 = Vec(-2), f32 = Vec(-7),
	f40 = Vec(-1, -18, 0), f41 = Vec(-2), f42 = Vec(-5),
}

local unfreeze = {
	f00 = Vec(-1, 21, 8), f01 = Vec(-22), f02 = Vec(-31),
	f10 = Vec(-22, 9, -1), f11 = Vec(-32), f12 = Vec(-25),
	f20 = Vec(-14, 0, 0), f21 = Vec(-19), f22 = Vec(-19),
	f30 = Vec(-10, -5, 0), f31 = Vec(-14), f32 = Vec(-19),
	f40 = Vec(4, -9, 0), f41 = Vec(-20), f42 = Vec(-23),
}

--[=[
local keys = {
	"tool_rot",
	"wrist",
	"f00", "f01", "f02",
	"f10", "f11", "f12",
	"f20", "f21", "f22",
	"f30", "f31", "f32",
	"f40", "f41", "f42",
}
local function drawposeparams(pose)
	SetString("game.player.tool", "physgun")
	UiMakeInteractive()
	UiPush()
	UiFont( "regular.ttf", 30 )
	for i = 1, #keys do
		local k, v = keys[i], pose[keys[i]] or Vec()
		pose[keys[i]] = v
		UiPush()
		UiTranslate( -2 )
		UiAlign( "right middle" )
		UiText( k )
		UiTranslate( 2 )
		UiAlign( "left middle" )
		for i = 1, 3 do
			UiRect( 135, 2 )
			UiTranslate( 90 )
			v[i] = math.floor(UiSlider( "ui/common/dot.png", "x", v[i], -90, 90))
			UiTranslate( 100, 0)
			UiText(v[i])
			UiTranslate( 40 )
		end
		UiPop()
		UiTranslate(0, 30)
	end
	UiPop()
end

function draw()
	UiPush()
		UiTranslate(100, 100)
		--drawposeparams(pose_list.grabbed[2])
	UiPop()
end
--]=]

local flash_offsets = {
	2, 2, 1, 2, 3, 4, 2, 3, 4, 2, 3, 4, 2, 3, 4, 1, 2, 3, 1
}

local anim_data = { dist = 1, fast = 2, pose = {}, hum_low = {0, 0}, hum_high = {0, 0} }
local t = 0
function TOOL:Animate( body, shapes )
	local last_action = state.action
	local dt = GetTimeStep()
	t = t + dt
	DrawBodyOutline(GetToolBody(), 0.4, 0.02, 0.3, math.sin( t * 2 - 0.4 ) / 2 + 0.7 )
	for i = 1, #flash_offsets do
		if shapes[i] then
			shapes[i]:DrawHighlight( math.max( 0, math.sin( t * 2 - flash_offsets[i] / 5 ) - 0.8 ) )
		end
	end

	local target_dist = math.atan(math.max((
		state.grabbed and
		state.dist or
		PLAYER:GetCamera():Raycast( 100, -1 ).dist
	) - 2, 0)) * 2 / math.pi
	anim_data.fast = approach( anim_data.fast, 2, dt * 20 )
	if last_action == "throw" then
		anim_data.fast = 10
	end

	anim_data.dist = approach( anim_data.dist, target_dist, dt * anim_data.fast )

	local pose_source = pose_list.default
	if state.grabbed then
		pose_source = pose_list.grabbed
	elseif state.grabbing then
		pose_source = pose_list.grabbing
	end
	approach_pose( anim_data.pose, lerp_pose( pose_source[1], pose_source[2], anim_data.dist ), dt * anim_data.fast * 5 )

	if last_action == "freeze" then
		anim_data.fast = 0
		for bone, val in pairs(freeze) do
			anim_data.pose[bone] = val
		end
	end
	if last_action == "unfreeze" then
		anim_data.fast = 0
		for bone, val in pairs(unfreeze) do
			anim_data.pose[bone] = val
		end
	end
	if state.rotating then
		local mult = anim_data.dist * 2 - 1
		edit_pose(anim_data.pose, "wrist", Vec(
			20 * InputValue( "cameray" ) * mult,
			20 * InputValue( "cameray" ) * (1 - math.abs(mult)),
			- 20 * InputValue( "camerax" )
		))
	end

	local breath = math.sin( t * 1.214213 ) / 2 + 0.5
	local armature = self.armature
	for bone, rot in pairs( anim_data.pose ) do
		if breathing[bone] then
			rot = VecAdd( rot, VecScale( breathing[bone], breath ) )
		end
		armature:SetBoneTransform( bone, Transform( Vec(), QuatEuler( rot[1], rot[2], rot[3] ) ) )
	end
	SetToolTransform( Transform( anim_data.pose.tool_pos, QuatEuler( anim_data.pose.tool_rot[1] + breathing.tool_rot[1] * breath, anim_data.pose.tool_rot[2], anim_data.pose.tool_rot[3] ) ) )

	armature:SetBoneTransform( "fa_1", Transform( Vec(), QuatLookAt(
		TransformToLocalPoint( armature:GetBoneGlobalTransform( "__FIXED_fa_1" ), Vec( 0, 0.05, 0 ) ),
		Vec(0, 0, 0)
	) ) )
	armature:SetBoneTransform( "fa_2", Transform( Vec(), QuatLookAt(
		TransformToLocalPoint( armature:GetBoneGlobalTransform( "__FIXED_fa_2" ), Vec( 0, -0.05, 0 ) ),
		Vec(0, 0, 0)
	) ) )
end

function TOOL:Deploy()
	local wobble = 0.2
	local wobble_constraint = {gravity = 0.3}
	self.armature:SetBoneJiggle("wrist", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f00", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f01", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f02", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f10", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f11", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f12", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f20", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f21", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f22", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f30", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f31", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f32", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f40", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f41", wobble, wobble_constraint)
	self.armature:SetBoneJiggle("f42", wobble, wobble_constraint)
end

function TOOL:DrawBeam( source, dir, object, line, r, g, b, drawline, a, b )
	local point, vel = source, dir
	local i = 0
	ParticleRadius(0.05, 0)
	while (point - object):Dot(line) < 0 do
		local diff = point - object
		local accel = diff - (diff:Dot(line) + 0.1) * line + vel / (35 + math.sin(GetTime()*a + b)*15)
		vel = vel - accel
		local nextp = point + vel / 50
		if drawline and i < 20 then
			DrawLine(point, nextp, r, g, b, (20-i)/200)
		end
		ParticleAlpha((100-i)/300, 0)
		SpawnParticle(point, vel / 10, 0.1)
		point = nextp
		i=i+1
		if i > 100 then break end
	end
end

local keys = {
	"f00", "f01", "f02",
	"f10", "f11", "f12",
	"f20", "f21", "f22",
	"f30", "f31", "f32",
	"f40", "f41", "f42",
}
local starts = {
	"palm", "f0_tip", "f1_tip", "f2_tip", "f3_tip", "f4_tip"
}
local function effect_t(time, duration)
	if not time then return end
	local t = (GetTime() - time) / duration
	if t >= 0 and t <= 1 then return t end
end
function TOOL:Tick(dt)
	local freeze_t = effect_t(state.effect.freeze_time, 1)
	if freeze_t then
		local body = state.effect.freeze_body
		body:DrawHighlight( .5 - freeze_t / 2 )
		body:DrawOutline( 0.4, 0.02, 0.3, 1 - freeze_t )
	end
	local unfreeze_t = effect_t(state.effect.unfreeze_time, 1)
	if unfreeze_t then
		local body = state.effect.unfreeze_body
		body:DrawHighlight( .5 - unfreeze_t / 2 )
		body:DrawOutline( 0.4, 0.02, 0.3, 1 - unfreeze_t )
	end

	anim_data.hum_low[2] = state.grabbing and 1 or 0
	anim_data.hum_high[2] = state.grabbed and 1 or 0
	anim_data.hum_low[1] = approach( anim_data.hum_low[1], anim_data.hum_low[2], dt * 2 )
	anim_data.hum_high[1] = approach( anim_data.hum_high[1], anim_data.hum_high[2], dt * 2 )
	if anim_data.hum_low[1] > 0 then
		PlayLoop(self.hum_low, GetPlayerCameraTransform().pos, anim_data.hum_low[1] * 0.4)
	end
	if anim_data.hum_high[1] > 0 then
		PlayLoop(self.hum_high, GetPlayerCameraTransform().pos, anim_data.hum_high[1] * 0.5)
	end
	if state.action == "freeze" then
		PlaySound(self.click1, GetPlayerCameraTransform().pos, 1)
	elseif state.action == "unfreeze" then
		PlaySound(self.click2, GetPlayerCameraTransform().pos, 1)
	elseif state.action == "throw" then
		PlaySound(self.hit, GetPlayerCameraTransform().pos, 1)
	end

	if GetPlayerVehicle() ~= 0 then return end

	local surge = math.max( 0, math.sin( t * 2 - 0.2 ) - 0.8 )
	ParticleReset()
	ParticleType("plain")
	ParticleEmissive(5)
	ParticleColor(0.4 + surge, 0.02 + surge, 0.3 + surge)
	ParticleTile(5)
	ParticleAlpha(1, 0)
	ParticleRadius(0.1, 0)
	ParticleGravity(10)
	for i = 1, #keys do
		local tr = self:GetBoneGlobalTransform( keys[i] )
		SpawnParticle(tr.pos, Vec(), 0.2)
	end

	local target
	if state.grabbed then
		state.grabbed:DrawOutline( 0.4 + surge, 0.02 + surge, 0.3 + surge, 1 )
		target = state.grabbed:GetTransform():ToGlobal(state.relative)
	elseif state.grabbing then
		local trace = PLAYER:GetPlayerCamera():Raycast(100, -1)
		target = trace.hitpos
	end
	if target then
		local line = (target - self:GetBoneGlobalTransform( "wrist" ).pos)
		for i = 1, #starts do
			local palm = self:GetBoneGlobalTransform( starts[i] )
			local p2 = palm:ToGlobalDir(Vector(0, 0, -2))
			self:DrawBeam(palm.pos, p2, target, line:Normalized(), 0.4 + surge, 0.02 + surge, 0.3 + surge, i > 1, 3 + line:Length()/50, i)
		end
	end
end

TOOL.model = {
	prefab = [[
		<prefab version="1.2.0">
			<group name="instance=MOD/physgun_hand.xml" pos="-15.95 0.5 15.525" rot="0.0 0.0 0.0">
				<group name="wrist" pos="0.0 0.025 -0.7" rot="0.0 0.0 0.0">
					<vox pos="-0.025 -0.05 -0.1" file="MOD/vox/hand.vox" object="hand" scale="0.5"/>
					<location name="palm" pos="0.0 -0.05 -0.1" rot="-90.0 0.0 0.0"/>
					<group name="f43" pos="0.045 -0.05 -0.11" rot="0 -20 0">
						<vox file="MOD/vox/hand.vox" object="hand_d" scale="0.5"/>
					</group>
					<group name="f00" pos="-0.06 -0.035 -0.02" rot="-9.1 31.5 64.2">
						<vox pos="-0.025 -0.025 -0.05" file="MOD/vox/hand.vox" object="f00" scale="0.5"/>
						<group name="f01" pos="0.0 0.0 -0.15">
							<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f01" scale="0.5"/>
							<group name="f02" pos="0.0 0.0 -0.05">
								<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f02" scale="0.5"/>
								<location name="f0_tip" pos="0.0 0.0 -0.05"/>
							</group>
						</group>
					</group>
					<group name="f10" pos="-0.05 -0.025 -0.19" rot="0.0 5.0 0.0">
						<vox pos="-0.025 -0.025 -0.05" file="MOD/vox/hand.vox" object="f10" scale="0.5"/>
						<group name="f11" pos="-0.0 0.0 -0.1">
							<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f11" scale="0.5"/>
							<group name="f12" pos="0.0 0.0 -0.05">
								<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f12" scale="0.5"/>
								<location name="f1_tip" pos="0.0 0.0 -0.05"/>
							</group>
						</group>
					</group>
					<group name="f20" pos="0.0 -0.025 -0.2">
						<vox pos="-0.025 -0.025 -0.05" file="MOD/vox/hand.vox" object="f20" scale="0.5"/>
						<group name="f21" pos="-0.0 0.0 -0.1">
							<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f21" scale="0.5"/>
							<group name="f22" pos="0.0 0.0 -0.05">
								<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f22" scale="0.5"/>
								<location name="f2_tip" pos="0.0 0.0 -0.05"/>
							</group>
						</group>
					</group>
					<group name="f30" pos="0.05 -0.025 -0.19" rot="0.0 -5.0 0.0">
						<vox pos="-0.025 -0.025 -0.05" file="MOD/vox/hand.vox" object="f30" scale="0.5"/>
						<group name="f31" pos="-0.0 0.0 -0.1">
							<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f31" scale="0.5"/>
							<group name="f32" pos="0.0 0.0 -0.05">
								<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f32" scale="0.5"/>
								<location name="f3_tip" pos="0.0 0.0 -0.05"/>
							</group>
						</group>
					</group>
					<group name="f40" pos="0.1 -0.025 -0.19" rot="0.0 -10.0 0.0">
						<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f40" scale="0.5"/>
						<group name="f41" pos="-0.0 0.0 -0.05">
							<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f41" scale="0.5"/>
							<group name="f42" pos="0.0 0.0 -0.05">
								<vox pos="-0.025 -0.025 0.0" file="MOD/vox/hand.vox" object="f42" scale="0.5"/>
								<location name="f4_tip" pos="0.0 0.0 -0.05"/>
							</group>
						</group>
					</group>
					<group name="fa_1" pos="-0.04 -0.025 0.0" rot="0.0 0.0 0.0">
						<vox pos="-0.025 -0.025 0.35" rot="0.0 0.0 0.0" file="MOD/vox/hand.vox" object="fa_1" scale="0.5"/>
					</group>
					<group name="fa_2" pos="0.04 -0.025 0.0" rot="0.0 0.0 0.0">
						<vox pos="-0.025 -0.025 0.35" rot="0.0 0.0 0.0" file="MOD/vox/hand.vox" object="fa_2" scale="0.5"/>
					</group>
				</group>
			</group>
		</prefab>
	]],
	objects = {
		{ "hand_d", Vec( 1, 3, 1 ) },
		{ "f02", Vec( 1, 1, 1 ) },
		{ "f01", Vec( 1, 1, 1 ) },
		{ "f00", Vec( 1, 3, 1 ) },
		{ "f22", Vec( 1, 1, 1 ) },
		{ "f21", Vec( 1, 1, 1 ) },
		{ "f20", Vec( 1, 2, 1 ) },
		{ "f12", Vec( 1, 1, 1 ) },
		{ "f11", Vec( 1, 1, 1 ) },
		{ "f10", Vec( 1, 2, 1 ) },
		{ "f32", Vec( 1, 1, 1 ) },
		{ "f31", Vec( 1, 1, 1 ) },
		{ "f30", Vec( 1, 2, 1 ) },
		{ "f42", Vec( 1, 1, 1 ) },
		{ "f41", Vec( 1, 1, 1 ) },
		{ "f40", Vec( 1, 1, 1 ) },
		{ "hand", Vec( 3, 4, 1 ) },
		{ "fa_2", Vec( 1, 14, 1 ) },
		{ "fa_1", Vec( 1, 14, 1 ) },
	},
}

RegisterToolUMF( "physgun", TOOL, state.bottom )