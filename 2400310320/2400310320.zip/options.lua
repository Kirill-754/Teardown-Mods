--[[
#include "umf.lua"
#include "tool_skins.lua"
#include "version.lua"
]] --
local function bool( id, invert )
	id = "savegame.mod." .. id
	invert = not invert
	return function()
		return GetBool( id ) == invert
	end
end

local toolgroups = {
	"[1] Basic",
	"[2] Construction",
	"[3] Guns",
	"[4] Explosives",
	"[5] Special",
	"[6] Custom",
}

local _, skins = pcall(ListSkins, "physgun", {["local-physgun"] = 1, ["steam-2400310320"] = 2})
local selected_skin = HasKey( "savegame.mod.skin") and GetString( "savegame.mod.skin" ) or DEFAULT_SKIN

local function rebuild_skin_options( skin )
	local options = {}
	if skin then
		if skin.config then
			options.title = "Skin Options"
			for key, value in pairs( skin.config ) do
				if value.type == "checkbox" then
					options[#options+1] = OptionsMenu.Toggle {
						id = "skin." .. skin.id .. "." .. key,
						name = value.name,
						default = value.default
					}
				end
			end
		end
	end
	return OptionsMenu.Group( options )
end

local skin_options = rebuild_skin_options(skins[selected_skin])

OptionsMenu {
	title = "Physics Gun",

	OptionsMenu.Spacer( 50 ),

	OptionsMenu.Columns {

		OptionsMenu.Group {

			title = "Options",

			OptionsMenu.Toggle { id = "legacy", name = "Legacy Rotation", default = false },
			OptionsMenu.Slider {
				id = "rotspeed",
				name = "Rotation Speed",
				min = 0.25,
				max = 4,
				step = 0.05,
				default = 1,
				condition = bool( "legacy", true ),
			},

			--OptionsMenu.Toggle { id = "bottom", name = "Prioritize in Tool List", default = true },

			OptionsMenu.Spacer( 50 ),

			OptionsMenu.Group {
				title = "Keybinds",

				OptionsMenu.Toggle { id = "key.invert", name = "Invert Mouse Buttons", default = false },
				OptionsMenu.Keybind { id = "key.rotate", name = "Rotate", default = "interact" },
				OptionsMenu.Keybind { id = "key.throw", name = "Throw", default = "r" },
				OptionsMenu.Keybind { id = "key.unfreeze", name = "Unfreeze", default = "r" },
				OptionsMenu.Keybind { id = "key.rotlock", name = "Toggle Rotation-Lock", default = "mmb", allowmouse = true, condition = bool("experimental.rotlock") },
			},

			OptionsMenu.Spacer( 50 ),

			OptionsMenu.Group {
				title = "Experimental",

				OptionsMenu.Toggle { id = "experimental.constrain", name = "Use New Constraint System", default = false },
				OptionsMenu.Toggle { id = "experimental.rotlock", name = "Enable Rotation-Lock toggle", default = false },
				OptionsMenu.Slider {
					id = "experimental.toolgroup",
					name = "Tool Group",
					min = 1,
					max = 6,
					step = 1,
					default = 6,
					setter = SetInt,
					getter = GetInt,
					formatter = function( val ) return toolgroups[val] or tostring( val ) end
				},
			},
		},

		OptionsMenu.Group {

			title = "Appearance",

			function()
				local w, h = 300, 200
				UiPush()
					UiAlign( "top left" )
					UiFont( "regular.ttf", 30 )
					UiTranslate( (-w-h) / 2 - 5, 0 )
					local mouseOver = UiIsMouseInRect( w, h )
					UiPush()
						UiWindow( w, h, true )
						UiColor( 1, 1, 1, 0.07 )
						UiImageBox( "ui/common/box-solid-6.png", w, h, 6, 6 )

						UiTranslate(10, 10)
						UiAlign("left")
						UiColor(0.95,0.95,0.95,1)
						for i=1, #skins do
							UiPush()
								UiColor(0,0,0,0)
								if skins[i].id == selected_skin then
									UiColor(1,1,1,0.1)
									if skins[i].disabled then
										UiColor(1,0.2,0.1,0.1)
									end
								else
									if mouseOver and UiIsMouseInRect(w - 20, 30) then
										UiColor(0,0,0,0.1)
										if InputPressed("lmb") then
											UiSound("../ui/terminal/message-select.ogg")
											selected_skin = skins[i].id
											if skins[i].disabled then
												UiSound("../ui/terminal/tool.ogg")
											else
												UiSound("../ui/terminal/message-select.ogg")
												SetString( "savegame.mod.skin", selected_skin )
											end
											skin_options = rebuild_skin_options(skins[selected_skin])
										end
									end
								end
								UiRect(w - 20, 30)
							UiPop()
							UiPush()
								UiTranslate(0, 24)
								UiText(skins[i].name)
							UiPop()
							UiTranslate(0, 32)
						end
					UiPop()
					local active = skins[selected_skin]
					local icon = active.icon or "MOD/tool_skins/unknown.jpg"
					UiPush()
						UiTranslate( 305, 0 )
						local iw, ih = UiGetImageSize( icon )
						UiScale( h / iw, h / ih )
						UiImage( icon )
					UiPop()
					UiTranslate( (w+h)/2, h + 20 )
					if active.desc then
						UiPush()
							UiAlign( "center top" )
							local w, h = UiText( active.desc )
						UiPop()
						UiTranslate( 0, h + 20 )
					end
					skin_options()
				UiPop()
				return 0, 0
			end,

		}
	},
}