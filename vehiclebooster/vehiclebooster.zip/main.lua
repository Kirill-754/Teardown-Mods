power = 0.2		-- Thrust power

function init()
	snd = LoadLoop("rocket.ogg")
end

function update()
	--Only active when player is in vehicle
	v = GetPlayerVehicle()
	if v > 0 then
		--Compute tail point and back direction on vehicle in world space
		local t = GetVehicleTransform(v)
		local p = TransformToParentPoint(t, Vec(0, 0.5, 3))
		local d = TransformToParentVec(t, Vec(0, 0, 1))

		if InputDown("up") then
			--Push the vehicle forwards
			local b = GetVehicleBody(v)	
			local v = GetBodyVelocity(b)
			v = VecAdd(v, VecScale(d, -power))
			SetBodyVelocity(b, v)

			--Engaged particle effects
			local pvel = VecScale(v, 0.7)
			SpawnParticle("fire", p, VecAdd(pvel, VecScale(d, 2)), 1.0, 0.5)
			SpawnParticle("smoke", p, VecAdd(pvel, VecScale(d, 5)), 1, 3.0)
			SpawnParticle("darksmoke", p, VecAdd(pvel, VecScale(d, 10)), 1.5, 1.0)
			
			--Play sound
			PlayLoop(snd, t.pos, 0.75)
		else
			--Idle particle effect
			SpawnParticle("fire", p, VecScale(d, 1), 0.3, 0.1)
			SpawnParticle("smoke", p, VecScale(d, 2), 0.5, 1.0)
		end
	end
end


