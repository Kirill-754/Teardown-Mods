Fuel_BigExplosionSound = {}

function init()
    a = GetPlayerCameraTransform()
    sb = FindBody("boeing")
    maxheight = 8
    boc = 130
    absolute = false
    b = FindShape("aircraft")
	boom = LoadSound("MOD/plane/CRJ-200 FUEL/snd/planecrashsound/0.ogg", 20)
	soundPlayed = false
end

function tick(dt)
    -- These need to be updated each tick for their new values/positions.
    strans = GetShapeWorldTransform(sc)
    spos = strans.pos
    flydirection = TransformToParentVec(strans, Vec(0, -1, 0))
    local sbt = GetBodyTransform(sb)
    local trVec = Vec(0,0, -boc)
    local trVel = TransformToParentPoint(sbt, trVec)
    local velSub = VecSub(trVel, sbt.pos)
    local bias = Vec(0, 0, 0)
    if not absolute then
        if (sbt.pos[2] < maxheight) then
            bias[2] = boc
            boc = boc
        end
        local currentVelocity = GetBodyVelocity(sb)
        SetBodyVelocity(sb, velSub)
    end
    if IsShapeBroken(b) then
		absolute = true
		if not soundPlayed then
			PlaySound(boom)
			soundPlayed = true
		end

	end
if boc > 100 then
	boc = 100
end
end