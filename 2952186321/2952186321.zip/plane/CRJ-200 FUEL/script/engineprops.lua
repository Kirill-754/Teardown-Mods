#include "particle.lua"
#include "generic.lua"

function init()

	blades = FindJoints("engine", true)

	hull = FindShape("engine_hull")
	SetShapeCollisionFilter(hull, 2, 255-2)
	outerblades = FindShapes("outerblade")
	for b=1, #outerblades do
		local outerblade = outerblades[b]
		SetShapeCollisionFilter(outerblade, 2, 255-2)
	end

	if GetPlayerVehicle() ~= 0 then
		for i = 1, #blades do
			local blade = blades[i]
			SetJointMotor(blade, 30)
		end
	end

	engineLoop = LoadLoop("MOD/main/CRJ-200 FUEL/snd/engine.ogg")
	engine_body = FindBody("engine")
end

function tick(dt)
	if engine_body ~= nil then
		if IsBodyBroken(engine_body) == false then
			local engine_pos = GetBodyTransform(engine_body).pos
			pTrans = GetPlayerTransform()
			if VecLength(VecMult(VecSub(pTrans.pos,engine_pos),Vec(1,1,0.4))) < 5 then
				SetPlayerVelocity(VecAdd(GetPlayerVelocity(),Vec(0,0,1)))
				if VecLength(VecSub(pTrans.pos,engine_pos))<2.5 then
					SetPlayerHealth(0)
					SetPlayerVelocity(Vec(0,0,5))
					pTrans.pos[3]= pTrans.pos[3]+3
					SetPlayerTransform(pTrans)
				end
			end
			PlayLoop(engineLoop,engine_pos,2/VecLength(VecSub(pTrans.pos,engine_pos)))
		end
	end
end


function GetBodyVoxelCount(body)
	local broken = 0
	local voxels = 0
	local shapes = GetBodyShapes(body)
	for s, shape in pairs(shapes) do
		voxels = voxels + GetShapeVoxelCount(shape)
		if IsShapeBroken(shape) then
			broken = broken + 1
		end
	end
	return voxels, broken, #shapes
end

function VecMult(a,b)
	return Vec(a[1]*b[1],a[2]*b[2],a[3]*b[3])
end
