speed = 1 -- thanks to iaobardar and yulun from the Teardown Discord for helping me

function init()
    up = FindShape("up")
    down = FindShape("down")
	JointTargetPosition = 0
    joints = FindJoints("holder") --tag both joints with holder
    limits = {}
    for i, j in ipairs(joints) do
        limits[i] = j
        SetJointMotorTarget(j, 0, speed, 1000)
    end
end

function tick(dt)
    local move = 0
    if InputDown("interact") then
	holding = false
	local shape = GetPlayerInteractShape()
	move = (shape == up) and 1 or (shape == down) and -1 or 0
	JointTargetPosition = GetJointMovement(joints[1]) + move * 10
else
	if not holding then
		holding = true
		JointTargetPosition = GetJointMovement(joints[1])
	end
end
    for i, j in ipairs(joints) do
        SetJointMotorTarget(joints[i], JointTargetPosition, speed, 1000)
    end
end