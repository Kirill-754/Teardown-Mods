visible = 0

function init()
	SetValue("visible", 1.0, "cosine", 0.5)
end

function tick()
	--Put a scripting menu button on the pause menu for all levels, except the main menu
	if not string.find(GetString("game.levelpath"), "main.xml") then
		if PauseMenuButton("Minecraft Map Menu") then
			StartLevel("", "MOD/main.xml")
		end
	end
end


function draw()	
	local path = GetString("game.levelpath")
	if string.find(path, "lightswitch.xml") then
		infoBox("This example shows an interactable light switch which turns a light on and off. You can find the script in script/lightswitch.lua.\n\nThe red button uses the interact tag which will make an interact notification show up. By changing the value of the interact tag from the script it is possible to display a different text for turning on and turning off the light.")
	elseif string.find(path, "radio.xml") then
		infoBox("A radio you can turn on or off. It is similar to the light switch, but will also react to the radio being broken. The script is located in script/radio.lua")
	elseif string.find(path, "elevator.xml") then
		infoBox("There are many pitfalls when making an elevator script. Take into consideration that the player might want to abort the current motion, switch direction while moving and that the elevator can get stuck on dynamic objects. Here is an example implementation using a prismatic joint and the SetJointMotorTarget function. You can find the code in script/elevator.lua")
	elseif string.find(path, "laser.xml") then
		infoBox("This example shows how the QueryRaycast function can be used to implement a laser beam. Light flashes and particle effects are used when an object is hit. After a few moments, the MakeHole function is called to carve out a hole in the hit object. The code is available in script/laser.lua")
	elseif string.find(path, "turret.xml") then
		infoBox("A turret that will turn towards the player and shoot when player is visible. The turrent uses a raycast to determine if player is visible and SetJointMotor to turn the turret. The code for this example can be found in script/turret.lua")
	elseif string.find(path, "forcefield.xml") then
		infoBox("This example showcase a fan that applies force to dynamic bodies. A scene query is used to collect shapes from the environment and impulses are applied to the corresponding bodies. The code is in script/forcefield.lua")
	elseif string.find(path, "weather.xml") then
		infoBox("A dynamic weather cycle going from rain to clear sky and back again. The code can be found in script/weather.lua")
	elseif string.find(path, "flyover.xml") then
		infoBox("A camera flyover by interpolating the camera transform between two location transforms. The code can be found in script/flyover.lua")
	elseif string.find(path, "savegame.xml") then
		infoBox("Shoot the barrels to increase score. Try running this example twice to see that the persistent score is remembered even if the game is restarted. The code for each barrel can be found in script/savegame-target.lua and the code that reads back the score and prints it on the screen is in script/savegame-display.lua")
	end
end


function infoBox(txt)
	UiPush()
		UiFont("regular.ttf", 22)
		UiWordWrap(500)

		local w,h = UiGetTextSize(txt)
		UiTranslate(20-600*(1-visible), UiHeight()-h-50)
		UiColor(0,0,0, 0.7)
		UiImageBox("ui/common/box-solid-10.png", w+40, h+30, 10, 10)
		UiTranslate(20, 35)
		
		UiColor(1,1,1)
		UiText(txt)
	UiPop()
end
