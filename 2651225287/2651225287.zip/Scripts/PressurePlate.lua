
function init()
	trigger = FindTrigger("PlateTrigger", true)
	Plate = FindShape("PressurePlate", true)
	TNT = FindLocation("TNT", true)

end

function update(dt)
	local p = GetPlayerPos()
	local t = GetLocationTransform(TNT)
	
	if IsPointInTrigger(trigger, p) then
		if IsShapeBroken(Plate) then
			RemoveTag(Plate, "interact")
		else
			Explosion(t.pos, 5)
		end
	end
end


