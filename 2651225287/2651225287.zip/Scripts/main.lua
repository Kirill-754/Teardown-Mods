-- Custom heist mission implementation
-- This script requires heist.lua in the level to work properly

function init()
	state = ""
	
	savedScore = false
	highScore = false
	score = 0
	timeLeft = 0

	endTimer = 0
	endScreen = 0

	endScreenScale = 0
	endScreenHeight = 300
end


function tick(dt)
	--Read the current level state. This is set by heist.lua
	state = GetString("level.state")
	
	--If level is completed we need to deal with score
	if state == "win" and not savedScore then
		--Get the score from registry. These values are set by heist.lua
		score = GetInt("level.clearedprimary") + GetInt("level.clearedsecondary")
		timeLeft = GetFloat("level.timeleft")

		--Save the new score if it's better than the current highscore
		local oldScore = GetInt("savegame.mod.score")
		local oldTimeLeft = GetFloat("savegame.mod.timeleft")
		if score > oldScore or (score == oldScore and timeLeft > oldTimeLeft) then
			highScore = true
			SetInt("savegame.mod.score", score)
			SetFloat("savegame.mod.timeleft", timeLeft)
		end

		--Do this only once
		savedScore = true
	end
	
	--If level is no longer in default state we need to handle win and lose
	if state ~= "" then
		
		--Wait two seconds to allow the escape vehicle to drive off
		endTimer = endTimer + dt	
		if endTimer > 2 then	
			if endScreen == 0 then
				SetValue("endScreen", 1, "cosine", 0.25)
			end
		end
	end
end


function draw()
	--End screen
	if endScreen > 0 then
		--Set gEndScreenScale to ease in the end screen
		SetValue("endScreenScale", 1, "easeout", 0.5)
		--Call to draw the endscreen
		drawEndScreen(endScreenScale, state)					
	end	
end


function drawEndScreen(f, state)
	if f > 0 then
		UiPush()
			--This will bring up the mouse pointer and accept input
			UiMakeInteractive()

			--here we use the f parameter that is sent to the function to make the side bar slide in
			UiTranslate(-300+300*f, 0)

			--Dialog
			UiAlign("top left")
			UiColor(0, 0, 0, 0.7*f)
			UiRect(400, UiHeight())
			UiWindow(400, UiHeight())
			UiColor(1,1,1)
			UiPush()
				UiTranslate(0, 50)
				if state == "win" then
					--If state is win we display the mission complete screen, with score and time left
					UiPush()
						UiTranslate(UiCenter(), 0)
						UiAlign("center top")
						UiFont("bold.ttf", 44)
						UiScale(2)
						UiText("MISSION")
						UiTranslate(0, 35)
						UiScale(0.7)
						UiText("COMPLETED")
					UiPop()

					UiTranslate(0, 0)

					UiPush()
						UiTranslate(UiCenter(), 150)
						UiAlign("center")
						UiFont("bold.ttf", 32)
						if highScore then
							UiText("New highscore "..score)
						else
							UiText("Score "..score)
						end

						UiTranslate(0, 120)	
						UiFont("regular.ttf", 22)

						_, h = UiText("Primary targets " .. GetInt("level.clearedprimary"))
						UiTranslate(0, h)
						_, h = UiText("Secondary targets " .. GetInt("level.clearedsecondary"))
						UiTranslate(0, h)
						_, h = UiText("Time left " .. math.floor(timeLeft*10)/10 .. "s")
					UiPop()
					UiTranslate(0, h)
				else
					--If state isn't win we draw the mission failed screen with the reason for failure.
					local h
					UiPush()
						UiTranslate(UiCenter(), 0)
						UiAlign("center top")
						UiPush()
							UiFont("bold.ttf", 44)
							UiScale(2)
							UiColor(.8, 0, 0)
							UiText("MISSION")
							UiTranslate(0, 32)
							UiScale(1.27)
							UiColor(1, 0, 0)
							UiText("FAILED")
						UiPop()
						UiFont("regular.ttf", 22)
						UiAlign("top left")
						UiTranslate(-144, 180)
						UiColor(.8, .8, .8)
						UiWordWrap(290)
						local reason = ""
						if state == "fail_dead" then
							reason = "You died. Explosions, fire, falling and bullets can hurt you. Keep an eye on the health meter"
						elseif state == "fail_alarmtimer" then
							reason = "You failed to escape before security arrived. Make sure to plan properly."
						elseif state == "fail_missiontimer" then
							reason = "You ran out of time. Try again and find better shortcuts."
						end
						_,h = UiText(reason)
					UiPop()
					UiTranslate(0, 40+h)
				end
			UiPop()
			UiTranslate(0, UiHeight()-endScreenHeight)
			
			--Buttons at bottom
			UiPush()
				UiTranslate(UiCenter(), 0)
				UiFont("regular.ttf", 26)
				UiAlign("center middle")
				UiButtonImageBox("common/box-outline-6.png", 6, 6, 1, 1, 1, 0.8)

				--If state is win we add the play again button
				if state == "win" then
					UiPush()
						UiTranslate(0, -20)
						UiColor(.7, 1, .8, 0.2)
						UiImageBox("common/box-solid-6.png", 260, 40, 6, 6)
						UiColor(1,1,1)
						if UiTextButton("Play again", 260, 40) then
							Restart()
						end
					UiPop()
					UiTranslate(0, 47)
				end

				--Add the quickload button if we are able to quick load
				UiPush()
					if not GetBool("game.canquickload") then
						UiDisableInput()
						UiColorFilter(1,1,1,0.5)
					end
					if UiTextButton("Quick load", 260, 40) then
						Command("game.quickload")
					end
				UiPop()
				UiTranslate(0, 47)

				--If the state isn't win we add the restart mission button
				if state ~= "win" then
					if UiTextButton("Restart mission", 260, 40) then
						Restart()
					end
					UiTranslate(0, 47)
				end
					
				--Add button to go back to the main menu
				UiTranslate(0, 20)
				if UiTextButton("Main menu", 220, 40) then
					Menu()
				end
				UiTranslate(0, 47)

				_,endScreenHeight = UiGetRelativePos()
			UiPop()
		UiPop()
	end
end