function draw()	
	UiMakeInteractive()
	
	UiPush()
		UiAlign("center middle")
		UiFont("bold.ttf", 32)

		UiTranslate(UiCenter(), 200)
		UiPush()
			UiScale(3)
			UiText("Minecraft Desert Village")
		UiPop()
		
		UiTranslate(0, 70)
			UiScale(1.5)
			UiText("Select a mode from the list")
		
		UiTranslate(-90, 100)
		
		UiAlign("left")
		
		if UiTextButton("Village and Temple") then StartLevel("", "MOD/DesertVillageSandbox.xml") end
		UiTranslate(0, 60)
		
		if UiTextButton("LowFPS") then StartLevel("", "MOD/DesertVillageSandboxLowFPS.xml") end
		UiTranslate(0, 60)
		
		if UiTextButton("Village Only") then StartLevel("", "MOD/DesertVillageSandboxVillageOnly.xml") end
		UiTranslate(0, 60)
		
		if UiTextButton("Temple Only") then StartLevel("", "MOD/DesertVillageSandboxTempleOnly.xml") end
		UiTranslate(0, 60)
	UiPop()
	
	UiPush()
		UiAlign("center middle")
		UiFont("regular.ttf", 20)

		UiTranslate(UiCenter(), 1050)
		UiPush()
			UiText("The 'Low FPS' version makes the ground solid, removes the background and the pressureplate trigger from the temple. As well as reduces the amount of 'mobs'.")
		UiPop()
	UiPop()
end
