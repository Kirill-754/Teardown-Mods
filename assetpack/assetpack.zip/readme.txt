The assets in this pack may be used in 3rd party mods according to the Teardown EULA.

Usage:

Copy the assets folder to the root of your mods folder (important for the pre-setup instances like doors and vehicles to work)


File type explanation:

*.vox - MagicaVoxel files. 
  Used as "Vox" objects in the Editor. 
  Some *.vox files contains multiple objects that can be grouped logically such as all the parts of a vehicle or different types of outer walls. 
  Select a single object from a multi-object vox with the Vox property "object" in the Scene Explorer.
  Multi-object *.vox files are usually named with a plural "-s" such as "suitcases.vox"

*.xml - XML files. 
  Used as "instance" object in the Editor. 
  Create a new instance and select the XML file in the Instance property "file" 
  An instance is the blueprint for a combination of objects where one or more objects can be vox files

Example 

container-red.vox <- Vox file with 4 objects (body, frame, door_left, door_right)
container_red.xml <- Instance with the 4 objects in container_red.vox and 2 joints on each of doors

container_blue.vox <- Vox file with 1 object


Contents:

main.xml                                 A showcase scene with all assets presented and a small scene built with assets from the pack

furniture/
    bedroom_oldie.vox                    Bedroom furniture in an oldish style
    diningroom_dark.vox                  Diningroom furniture in dark wood
    industrial.vox                       Industrial stuff like cabinets, fences and palett shelfs
    livingroom_oldie.vox                 Livingroom furniture in an oldish style
    office_murky.vox                     Dark murky office furniture
    office_supplies.vox                  Office supplies like a printer, a whiteboard and such
    potted_plants.vox                    Assortment of potted plants in different sizes

industrial/
    beams.vox                            Wood and steel beams in different dimensions
    components.vox                       Basic construction blocks like walls, windows, stairs and such
    door-inner-wood.xml                  The instance prefab for a readily setup and functional inner door
    door-outer-wood.xml                  The instance prefab for a readily setup and functional outer door
    doors.vox                            A wooden inner door and an outer wooden door
    innerceilings.vox                    Two sizes of tiled inner roofs and one untiled
    innerfloors.vox                      Plank and concrete inner floors
    innerwalls.vox                       Three different inner walls and a studded wooden framework
    lamp-ceiling-fixed.xml               The instance prefab for a fluorecent light armature to be attached flushed with the ceiling
    lamp-ceiling-globe.xml               The instance prefab for a globe light to be attached to the ceiling
    lamp-ceiling-hanging.xml             The instance prefab for a fluorecent light armature hanging from the ceiling
    lamp-wall-fluorecent-long.xml        The instance prefab for a long fluorecent light armature to be attached attached to a wall
    lamp-wall-fluorecent-short.xml       The instance prefab for a short fluorecent light armature to be attached attached to a wall
    lamps.vox                            An assortment of dirrerent lamps
    machinery.vox                        A collection of industrial machinery
    outerwalls.vox                       Three variants of outer walls and a suitable corner element
    pipes_and_ventilation.vox            Some pipes and ventilation elements of different sizes
    roofs.vox                            Four different roofs with joists. Each in three different gradations.
    wall-metal-blue.vox                  A blue industrial metal wall
    wall-metal-red.vox                   A red industrial metal wall

nature/
    bushes.vox                           An assortment of different sized bushes
    pine-huge.vox                        A huge pine tree
    pine-large.vox                       A large pine tree
    pine-medium.vox                      A medium pine tree
    pine-small.vox                       A small pine tree
    tree-birch.vox                       A birch tree
    tree-large.vox                       A large ordinary tree
    tree-medium.vox                      A medium ordinary tree
    tree-mediumlarge.vox                 A medium-large ordinary tree
    tree-scotspine.vox                   A scotspine
    tree-small-variant.vox               A variant of a small ordinary tree
    tree-small.vox                       Another variant of a small ordinary tree
    tree-sparse-winter.vox               A tree no leaves
    tree-sparse.vox                      A tree with sparse leaves

props/
    barrels.vox                          Five metal oil drums in different colors and a blue plastic barrel
    cabledrum.vox                        A wooden cable drum
    container-red.xml                    The instance prefab for a red container with openable doors
    container_blue.vox                   A blue container with fixed doors
    container_red.vox                    A red container with loose doors
    crates.vox                           Wooden crates of different sizes 
    dumpster.vox                         A red dumpster
    ladder.vox                           A small step ladder
    liquidcontainer.vox                  A plastic liquid container in a metal frame
    pallets.vox                          Different sizes of wooden pallets
    pallettruck.vox                      A yellow pallet hand-truck
    plasticcan.vox                       A plastic can
    propane_huge.vox                     A huge propane tank
    propane_small.vox                    A small propane tank
    pylone.vox                           A black and yellow warning pylone
    suitcases.vox                        A few suitcases of different sizes and colors
    toolbox.vox                          A toolbox
    trashcan-big.vox                     A big trashcan with a lid
    trashcan-big.xml                     The instance prefab for the big trashcan with openable lid
    trashcan.vox                         A regular trashcan

vehicles/
        land/
            castanet-500l-gt.vox         The classic pink Castanet 500 GT
            castanet-500l-gt.xml         The instance prefab for the Castanet
            crane.vox                    A mobile crane
            crane.xml                    The instance prefab for the mobile crane
            crownzygot-xvc.vox           The Crownzygot-XVC-Alpha
            crownzygot-xvc.xml           The instance prefab for the Crownzygot
            dumptruck.vox                A dumptruck
            dumptruck.xml                The instance prefab for the dumptruck
            excavator.vox                An excavator
            excavator.xml                The instance prefab for the excavator
            salooncar.vox                A very ordinary saloon car
            salooncar.xml                The instance prefab for the saloon car
            semitruck-us.vox             A US style semi truck
            semitruck-us.xml             The instance prefab for the semi truck
            stationwagon.vox             A station wagon
            stationwagon.xml             The instance prefab for the station wagon
            suv1.vox                     The suv1
            suv1.xml                     The instance prefab for the suv1
            taskmaster-4wd.vox           The Taskmaster 4WD
            taskmaster-4wd.xml           The instance prefab for the Taskmaster
            tractor.vox                  A tractor
            tractor.xml                  The instance prefab for the tractor
            van.vox                      A plain van
            van.xml                      The instance prefab for the van

        sea/
            mediumboat.vox               A medium sized boat
            mediumboat.xml               The instance prefab for the medium sized boat
            smallboat.vox                A small plastic boat
            smallboat.xml                The instance prefab for the small boat
            speedboat.vox                A sleek speed boat
            speedboat.xml                The instance prefab for the speed boat
            woodboat.vox                 A nice wooden boat
            woodboat.xml                 The instance prefab for the wooden boat
