function init()
	tv = FindShape("lobby_tv", true)
	tvPos = GetShapeWorldTransform(tv)
	tvPos = TransformToParentTransform(GetBodyTransform(FindBody("ground")), tvPos).pos
	screen = FindShape("tv_screen")
	broken = false
	display = 0
	
	if GetString("savegame.mod.bergweather") == "thunder" then
		sound = LoadLoop("LEVEL/sound/eas.ogg")
		display = 1
		pos = 2000
	else
		photo = math.random(1, 8)
		nextPhoto = photo + 1
		if nextPhoto > 8 then
			nextPhoto = 1
		end
		photoTimer = 5
		fade = 0
		alpha = 0.0
	end
end

function tick(dt)
	if not broken then
		if IsShapeBroken(tv) then
			--delete(screen)
			broken = true
		elseif display == 0 then
			if fade == 0 then
				photoTimer = photoTimer - dt
				if photoTimer <= 0 then
					photoTimer = 5
					nextPhoto = nextPhoto + 1
					if nextPhoto > 8 then
						nextPhoto = 1
					end
					fade = 1
				end
			end
		else --display == 1
			pos = pos - 10
			if pos <= -11000 then
				pos = 2000
			end
			
			PlayLoop(sound, tvPos)
		end
	end
end

function draw()
	if not broken then
		if display == 0 then
			UiImage("LEVEL/images/photo" .. photo .. ".jpg")
			if fade == 1 then
				UiColor(0,0,0, alpha)
				UiRect(UiWidth(), UiHeight())
				alpha = alpha + (GetTimeStep())
				if alpha >= 1 then
					photo = nextPhoto
					fade = 2
				end
			elseif fade == 2 then
				UiColor(0,0,0, alpha)
				UiRect(UiWidth(), UiHeight())
				alpha = alpha - (GetTimeStep())
				if alpha <= 0 then
					fade = 0
				end
			end
		else --display == 1
			UiTranslate(0, 0)
			UiImage("LEVEL/images/back.png")
			UiTranslate(pos, 200)
			UiImage("LEVEL/images/words.png")
		end
	end
end